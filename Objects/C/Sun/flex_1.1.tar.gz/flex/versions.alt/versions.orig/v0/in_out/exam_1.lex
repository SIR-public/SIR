%%
username	printf("%s",getlogin());
