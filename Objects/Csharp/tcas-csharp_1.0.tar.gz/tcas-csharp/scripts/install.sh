#!/bin/bash
# this is a generalized installation script for
# installing and compiling the C# version of
# tcas.  You can embed this script within another
# wrapper script or use it as a guide for how to
# select unfaulted and faulted versions of the
# subject.

if [ $# -lt 1 ]
then
    echo "usage: $0 version"
    echo "version: 0...41"
    echo "0 = original version"
    echo "1...41 faulted version 1 through 41"
    exit 1
fi

if [ ! ${experiment_root} ]
then
    echo "experiment_root unset, set in shell and retry request"
    exit 2
fi

if [ ${1} -eq ${1} 2> /dev/null ]
then
    ver=${1}
else
    echo "invalid version, non-numeric"
    exit 3
fi

if [ ${ver} -eq 0 ]
then   # handle orig install case
    cp ../source.alt/source.orig/* ../source
else   # handle faulted version case
    cp ../versions.alt/versions.orig/v${ver}/* ../source
fi
cd ../source
gmcs tcas.cs
ret=$?
if [ ${ret} -ne 0 ]
then
    echo build failed
fi
cd ../scripts
exit $ret
