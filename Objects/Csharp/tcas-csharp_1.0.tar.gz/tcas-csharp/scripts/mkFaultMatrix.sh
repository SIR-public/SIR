#!/bin/sh
#
# mkFaultMatrix.sh - makes a fault matrix using the faulted versions
#

if test $# -lt 4
then echo "Usage: $0 <Variant-Start> <Variant-End> <fault-matrix-name> <universe-file-name> [-s out-dir]" 
        echo "Variant-Start: 1...41"
        echo "Variant-End: 1...41"
        echo "fault-matrix-name: name of fault matrix output file to be created"
        echo "universe-file-name: path/name of universe file used for tests"
        echo "-s: save outputs of tests in out-dir/vF (F=fault)"
	exit 1
fi

if [ ! ${experiment_root} ]
then
    echo "Error: experiment_root unset, set it in the shell and retry"
    exit 2
fi

if [ ${1} -eq ${1} 2> /dev/null ]
then
    v=$1
else
    echo "Error: Variant-Start is non-numeric"
    exit 3
fi
if [ ${2} -eq ${2} 2> /dev/null ]
then
    vend=${2}
else
    echo "Error: Variant-End is non-numeric"
    exit 4
fi

if [ ${v} -gt ${vend} ]
then
    echo "Error: Variant-Start > Variant-End"
    exit 5
fi
#
# already know there are at least 4 args by if $# test above
# save fault matrix name and universe file name
#

fault_matrix_name=${3}

if [ -f ${4} ]
then
    universe=${4}
else
    echo "universe file ${4} cannot be found/opened, does it need a absolute/relative path?"
    exit 6
fi

save=0
#
# shift off the version and variant number info from the cmd line args
# to allow getopt to parse the rest of the cmds
#
shift 4
while getopts s: OPT
do
    case "$OPT" in
        s)
            savedir=$OPTARG
            save=1
            ;;
        \?)   # default case
            echo "Usage: $0 <Variant-Start> <Variant-End> <fault-matrix-name> <universe-file-name> [-s out-dir]" 
            exit 7
            ;;
    esac
done
 
# autodetect the awk provided on this platform
which awk > /dev/null 2>&1
have_awk=$?
which gawk > /dev/null 2>&1
have_gawk=$?
if [ ${have_awk} -eq 0 ]
then
    myawk=awk
elif [ ${have_gawk} -eq 0 ]
then
    myawk=gawk
else
    echo "no awk or gawk found, need this to compose the fault matrix, exitting."
    exit 8
fi

subject_root=${experiment_root}/c-sharp-tcas

PATH_SUBJECT=${subject_root}/source

#
# need monomts tool to build runall scripts from universe file
#
MTS_HOME=${HOME}/mts
CTOOLS=${HOME}/c-tools

PATH=${PATH}:${MTS_HOME}/bin/bsh
export PATH

#
# make runall and runall-diff scripts
# this requires the new monomts tool, which is a
# modified version of javamts, packaged with the
# mts tool on the SIR Tools page
#

$MTS_HOME/bin/bsh/monomts .. ../source/tcas.exe ${universe} R runall.sh NULL NULL NULL

${MTS_HOME}/bin/bsh/monomts .. ../source/tcas.exe ${universe} D runall-diff.sh NULL ../outputs.alt NULL

cwd=`pwd`

numtests=`cat ${universe} | wc -l`

#ascript=`${CTOOLS}/gen_fault_matrix/gen_temp_file F`
ascript=one-test-run.sh

all_diffs=`${CTOOLS}/gen_fault_matrix/gen_temp_file F`
diffs=`${CTOOLS}/gen_fault_matrix/gen_temp_file F`

# Create oracle test output
# the install.sh script knows that 0 means the unfaulted
# version should be installed

../scripts/install.sh 0
cd ../source
../scripts/runall.sh
cd ../scripts
mv ../outputs/* ../outputs.alt

#loop thru versions
while ( test $v -le $vend )
do
    rm -f ../outputs/*
    ../scripts/install.sh $v
    if [ $? -eq 0 ]
    then
        n=0
        while (test $n -lt $numtests)
        do
            echo Doing for test ${n}
            nplus=`expr $n + 1`
            ${myawk} -f ${CTOOLS}/gen_fault_matrix/extract_from_script.awk -v num_test=${n} runall-diff.sh > ../scripts/${ascript}
#            touch ${ascript}
            chmod u+x ${ascript}
            rm -f -r ../outputs/*
            cd ../source
            ../scripts/${ascript} > ${diffs}
            cd ../scripts
            temp1=`${myawk} -f ${CTOOLS}/gen_fault_matrix/process_diffs.awk ${diffs}`
            echo "Version:${v}" ${temp1} >> ${all_diffs}
            n=${nplus}
            #read ugh
        done
        if [ ${save} -eq 1 ]   # save output for diagonostic/manual compare
        then
            if [ ! -d ${savedir}/v${v}.${fault} ]
            then
                mkdir ${savedir}/v${v}.${fault}
            fi
            cp ../outputs/* ${savedir}/v${v}.${fault}
        fi
        echo done with version ${v}
    else    # bad fault - fails to compile
        echo "bad fault ${fault} pad fault table data..."
        tcounter=0
	while [ ${tcounter} -lt $numtests ]
	do
	    echo "Version:${v} Test:${tcounter} Exposed:0" >> ${all_diffs}
	    tcounter=`expr ${tcounter} + 1`
	done
    fi
    v=`expr ${v} + 1`
done
${CTOOLS}/gen_fault_matrix/combine_fault_data ${all_diffs} ${universe} ${fault_matrix_name}
cp ${fault_matrix_name} ${subject_root}/info/${fault_matrix_name}
