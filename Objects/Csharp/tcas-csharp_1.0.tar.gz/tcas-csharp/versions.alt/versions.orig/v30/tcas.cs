﻿using System;

    public class tcas
    {
        const int OLEV = 600;		/* in feets/minute */
        const int MAXALTDIFF = 600;		/* max altitude difference in feet */
        const int MINSEP = 300;          /* min separation in feet */
        const int NOZCROSS = 100;		/* in feet */
        /* variables */

        int Cur_Vertical_Sep;
        bool High_Confidence;
        bool Two_of_Three_Reports_Valid;

        int Own_Tracked_Alt;
        int Own_Tracked_Alt_Rate;
        int Other_Tracked_Alt;

        int Alt_Layer_Value;		/* 0, 1, 2, 3 */
        int[] Positive_RA_Alt_Thresh = new int[4];

        int Up_Separation;
        int Down_Separation;

        /* state variables */
        int Other_RAC;			/* NO_INTENT, DO_NOT_CLIMB, DO_NOT_DESCEND */
        const int NO_INTENT = 0;
        const int DO_NOT_CLIMB = 1;
        const int DO_NOT_DESCEND = 2;

        int Other_Capability;		/* TCAS_TA, OTHER */
        const int TCAS_TA = 1;
        const int OTHER = 2;

        bool Climb_Inhibit;		/* true/false */

        const int UNRESOLVED = 0;
        const int UPWARD_RA = 1;
        const int DOWNWARD_RA = 2;

        void initialize()
        {
            Positive_RA_Alt_Thresh[0] = 400;
            Positive_RA_Alt_Thresh[1] = 500;
            Positive_RA_Alt_Thresh[2] = 640;
            Positive_RA_Alt_Thresh[3] = 740;
        }

        int ALIM()
        {
            return Positive_RA_Alt_Thresh[Alt_Layer_Value];
        }

        int Inhibit_Biased_Climb()
        {
            return (Up_Separation + NOZCROSS); /*mutation*/
        }

        bool Non_Crossing_Biased_Climb()
        {
            bool upward_preferred;
            bool upward_crossing_situation;
            bool result;

            upward_preferred = Inhibit_Biased_Climb() > Down_Separation;
            if (upward_preferred)
            {
                result = !(Own_Below_Threat()) || ((Own_Below_Threat()) && (!(Down_Separation >= ALIM())));
            }
            else
            {
                result = Own_Above_Threat() && (Cur_Vertical_Sep >= MINSEP) && (Up_Separation >= ALIM());
            }
            return result;
        }

        bool Non_Crossing_Biased_Descend()
        {
            bool upward_preferred;
            bool upward_crossing_situation;
            bool result;

            upward_preferred = Inhibit_Biased_Climb() > Down_Separation;
            if (upward_preferred)
            {
                result = Own_Below_Threat() && (Cur_Vertical_Sep >= MINSEP) && (Down_Separation >= ALIM());
            }
            else
            {
                result = !(Own_Above_Threat()) || ((Own_Above_Threat()) && (Up_Separation >= ALIM()));
            }
            return result;
        }

        bool Own_Below_Threat()
        {
            return (Own_Tracked_Alt < Other_Tracked_Alt);
        }

        bool Own_Above_Threat()
        {
            return (Other_Tracked_Alt < Own_Tracked_Alt);
        }

        int alt_sep_test()
        {
            bool enabled, tcas_equipped, intent_not_known;
            bool need_upward_RA, need_downward_RA;
            int alt_sep;

            enabled = High_Confidence && (Own_Tracked_Alt_Rate <= OLEV) && (Cur_Vertical_Sep > MAXALTDIFF);
            tcas_equipped = Other_Capability == TCAS_TA;
            intent_not_known = Two_of_Three_Reports_Valid && Other_RAC == NO_INTENT;

            alt_sep = UNRESOLVED;

            if (enabled && ((tcas_equipped && intent_not_known) || !tcas_equipped))
            {
                need_upward_RA = Non_Crossing_Biased_Climb() && Own_Below_Threat();
                need_downward_RA = Non_Crossing_Biased_Descend() && Own_Above_Threat();
                if (need_upward_RA && need_downward_RA)
                    /* unreachable: requires Own_Below_Threat and Own_Above_Threat
                       to both be true - that requires Own_Tracked_Alt < Other_Tracked_Alt
                       and Other_Tracked_Alt < Own_Tracked_Alt, which isn't possible */
                    alt_sep = UNRESOLVED;
                else if (need_upward_RA)
                    alt_sep = UPWARD_RA;
                else if (need_downward_RA)
                    alt_sep = DOWNWARD_RA;
                else
                    alt_sep = UNRESOLVED;
            }

            return alt_sep;
        }
        static int Main(string[] args)
        {
            if (args == null || args.Length < 12)
            {
                Console.WriteLine("Error: Command line arguments are");
                Console.WriteLine("Cur_Vertical_Sep, High_Confidence, Two_of_Three_Reports_Valid");
                Console.WriteLine("Own_Tracked_Alt, Own_Tracked_Alt_Rate, Other_Tracked_Alt");
                Console.WriteLine("Alt_Layer_Value, Up_Separation, Down_Separation");
                Console.WriteLine("Other_RAC, Other_Capability, Climb_Inhibit");
                return 1;
            }
            int[] argv = new int[args.Length];
            for (int i = 0; i < argv.Length; i++)
            {
                argv[i] = int.Parse(args[i]);
            }
            tcas newobject = new tcas();
            newobject.initialize();
            newobject.Cur_Vertical_Sep = (argv[0]);
            newobject.High_Confidence = (argv[1]) != 0;
            newobject.Two_of_Three_Reports_Valid = (argv[2]) != 0;
            newobject.Own_Tracked_Alt = (argv[3]);
            newobject.Own_Tracked_Alt_Rate = (argv[4]);
            newobject.Other_Tracked_Alt = (argv[5]);
            newobject.Alt_Layer_Value = (argv[6]);
            newobject.Up_Separation = (argv[7]);
            newobject.Down_Separation = (argv[8]);
            newobject.Other_RAC = (argv[9]);
            newobject.Other_Capability = (argv[10]);
            newobject.Climb_Inhibit = (argv[11]) != 0;
            Console.WriteLine(newobject.alt_sep_test());
            return 0;
        }
    }

