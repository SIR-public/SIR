package intelement;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import junit.framework.TestCase;
import edu.ksu.cis.projects.bogor.kiasan.test.Util;
import edu.ksu.cis.projects.bogor.kiasan.translator.Method;
import edu.ksu.cis.projects.bogor.kiasan.util.VerySimpleFormatter;

public class BinaryHeapTest extends TestCase {
   public void initLogging() throws Exception{
        Handler fh = new FileHandler("cvcl.log");
        fh.setFormatter(new SimpleFormatter());
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").addHandler(fh);
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").setLevel(Level.ALL);
        Handler fhvm = new FileHandler("vmtrace.log");
        fhvm.setFormatter(new VerySimpleFormatter());
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan.util").addHandler(fhvm);
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan.util").setLevel(Level.ALL);
    }

    public void testDeleteMin() throws Exception {
       // initLogging();
        
        Util
            .testBogorVM(
                "intelement.BinaryHeap",                
                "kunitforward.bogor-conf",
                new Method("intelement.BinaryHeap",
                        "deleteMin",
                        "()I",
                        false),true,false);                
    }   
}
