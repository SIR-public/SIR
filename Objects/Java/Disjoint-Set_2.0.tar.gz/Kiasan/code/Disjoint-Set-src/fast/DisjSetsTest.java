package fast;
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import junit.framework.TestCase;
import edu.ksu.cis.projects.bogor.kiasan.test.Util;
import edu.ksu.cis.projects.bogor.kiasan.translator.Method;
import edu.ksu.cis.projects.bogor.kiasan.util.VerySimpleFormatter;

public class DisjSetsTest extends TestCase {
   public void initLogging() throws Exception{
        Handler fh = new FileHandler("cvcl.log");
        fh.setFormatter(new SimpleFormatter());
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").addHandler(fh);
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").setLevel(Level.ALL);
        Handler fhvm = new FileHandler("vmtrace.log");
        fhvm.setFormatter(new VerySimpleFormatter());
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan").addHandler(fhvm);
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan").setLevel(Level.ALL);
    }

    public void testFind() throws Exception {
       // initLogging();
        Util
            .testForwardKUnit(
               "fast.DisjSetsFast",                
                "kunitforward.bogor-conf",               
                new Method("fast.DisjSetsFast",
                        "Find",
                        "(I)I",
                        false),true,false);                
    }   
//    public void testUnion() throws Exception {
//        //initLogging();
//        Util
//           // .testBogorVM(
//           		.testForwardKUnit(
//                "fast.DisjSetsFast",                
//                "kunitforward.bogor-conf",               
//                new Method("fast.DisjSetsFast",
//                        "union",
//                        "(II)V",
//                        false),true,false);                
//    }   
}
