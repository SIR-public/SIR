
import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import junit.framework.TestCase;
import edu.ksu.cis.projects.bogor.kiasan.test.Util;
import edu.ksu.cis.projects.bogor.kiasan.translator.Method;
import edu.ksu.cis.projects.bogor.kiasan.util.VerySimpleFormatter;

public class DLLTest extends TestCase {
   public void initLogging() throws Exception{
        Handler fh = new FileHandler("cvcl.log");
        fh.setFormatter(new SimpleFormatter());
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").addHandler(fh);
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").setLevel(Level.ALL);
        Handler fhvm = new FileHandler("vmtrace.log");
        fhvm.setFormatter(new VerySimpleFormatter());
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan.util").addHandler(fhvm);
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan.util").setLevel(Level.ALL);
    }

    public void testRemoveLast() throws Exception {
       // initLogging();
        
        Util
            .testBogorVM(
                "DoubleLinkedList",                
                "kunit.bogor-conf",
                new Method("DoubleLinkedList",
                        "removeLast",
                        "()Ljava/lang/Object;",
                        false),true,true);                
    }   
    public void testClear() throws Exception {
        // initLogging();
         
         Util
             .testBogorVM(
                 "DoubleLinkedList",                
                 "kunit.bogor-conf",
                 new Method("DoubleLinkedList",
                         "clear",
                         "()V",
                         false),true,false);                
     }   
    public void testAddBefore() throws Exception {
        // initLogging();
         
         Util
             .testBogorVM(
                 "DoubleLinkedList",                
                 "kunit.bogor-conf",
                 new Method("DoubleLinkedList",
                         "addBefore",
                         "(Ljava/lang/Object;LDoubleLinkedList$Entry;)LDoubleLinkedList$Entry;",
                         false),true,false);                
     }   
 
    public void testRemove() throws Exception {
        // initLogging();
         
         Util
             .testBogorVM(
                 "DoubleLinkedList",                
                 "kunit.bogor-conf",
                 new Method("DoubleLinkedList",
                         "remove",
                         "(Ljava/lang/Object;)Z",
                         false),true,true);                
     }   
   public void testToArray() throws Exception {
        initLogging();
        
        Util
            .testBogorVM(
                "DoubleLinkedList",                
                "kunit.bogor-conf",
                new Method("DoubleLinkedList",
                        "toArray",
                        "()[Ljava/lang/Object;",
                        false),true,false);                
    }   
   public void testIndexOf() throws Exception {
       initLogging();
       
       Util
           .testBogorVM(
               "DoubleLinkedList",                
               "kunit.bogor-conf",
               new Method("DoubleLinkedList",
                       "indexOf",
                       "(Ljava/lang/Object;)I",
                       false),true,true);                
   }   
   public void testLastIndexOf() throws Exception {
       initLogging();
       
       Util
           .testBogorVM(
               "DoubleLinkedList",                
               "kunit.bogor-conf",
               new Method("DoubleLinkedList",
                       "lastIndexOf",
                       "(Ljava/lang/Object;)I",
                       false),true,true);                
   }   
}
