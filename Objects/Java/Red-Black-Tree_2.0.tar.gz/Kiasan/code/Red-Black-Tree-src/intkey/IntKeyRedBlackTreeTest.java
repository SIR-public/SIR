package intkey;


import java.util.logging.FileHandler;
import java.util.logging.Handler;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.util.logging.SimpleFormatter;

import junit.framework.TestCase;
import edu.ksu.cis.projects.bogor.kiasan.test.Util;
import edu.ksu.cis.projects.bogor.kiasan.translator.Method;
import edu.ksu.cis.projects.bogor.kiasan.util.VerySimpleFormatter;

public class IntKeyRedBlackTreeTest extends TestCase {
   public void initLogging() throws Exception{
        Handler fh = new FileHandler("theoremprover.log");
        fh.setFormatter(new SimpleFormatter());
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").addHandler(fh);
        Logger.getLogger("edu.ksu.cis.santos.util.theoremprover").setLevel(Level.ALL);
        Handler fhvm = new FileHandler("vmtrace.log");
        fhvm.setFormatter(new VerySimpleFormatter());
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan.util").addHandler(fhvm);
        Logger.getLogger("edu.ksu.cis.projects.bogor.kiasan.util").setLevel(Level.ALL);
    }
//    public void testRemove() throws Exception {
//        //initLogging();
//        Util
//            .testBogorVM(
//                "intkey.TreeMap",                
//                "kunit.bogor-conf",                
//                new Method("intkey.TreeMap",
//                        "remove",
//                        "(I)Ljava/lang/Object;",
//                        false),true,false);                
//    }   
//    public void testLastKey() throws Exception {
//        //initLogging();
//        Util
//            .testBogorVM(
//                "intkey.TreeMap",                
//                "kunit.bogor-conf",                
//                new Method("intkey.TreeMap",
//                        "lastKey",
//                        "()I",
//                        false),true,false);                
//    }   

    public void testPut() throws Exception {
      //  initLogging();
        Util
            .testForwardKUnit(
                "intkey.TreeMap",                
                "kunitforward.bogor-conf",                
                new Method("intkey.TreeMap",
                        "put",
                        "(ILjava/lang/Object;)Ljava/lang/Object;",
                        false),true,false);                
    }   
//    public void testGet() throws Exception {
//       // initLogging();
//        Util
//            .testForwardKUnit(
//                "intkey.TreeMap",                
//                "kunitforward.bogor-conf",                
//                new Method("intkey.TreeMap",
//                        "get",
//                        "(I)Ljava/lang/Object;",
//                        false),true,false);                
//    }   
}
