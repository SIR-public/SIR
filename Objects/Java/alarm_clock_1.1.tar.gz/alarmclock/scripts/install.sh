#!/bin/sh

if [ ! ${experiment_root} ]
then
    echo "experiment_root is unset in the shell"
    echo "please set experiment_root to point to your experiment directory"
    echo "see README for more information:"
    exit 2
fi

if test $# -lt 1
	then \
		echo Usage:
		echo install.sh comp_dir [variant]
		echo comp_dir: orig
                echo "variant (optional): 4 or 9 default=4"
		exit 0
fi

# set alarmclock variant to user supplied or default value
if [ $# -eq 2 ]
then
    variant=${2}
    if [ ${variant} -ne 4 -a ${variant} -ne 9 ]
    then
        echo Usage:
        echo install.sh comp_dir [variant]
	echo comp_dir: orig
        echo "variant (optional): 4 or 9 default=4"
	exit 1
    fi
else
    variant=4
fi

subject_dir=${experiment_root}/alarmclock
echo removing old files
rm -f -r ${subject_dir}/source/*
rm -f ${subject_dir}/outputs/*

if test $1 = "orig"
then
     echo copying files for orig version for alarmclock variant ${variant}
     cp -r ${subject_dir}/versions.alt/orig/ac${variant}/*.java ${subject_dir}/source 
else
    echo orig is the only option currently available
    exit 0
fi
cd ${subject_dir}/source

echo compiling application
echo "java home"
echo $JAVA_HOME
find . -name "*.java" | xargs javac -deprecation -source 1.4 > /dev/null

