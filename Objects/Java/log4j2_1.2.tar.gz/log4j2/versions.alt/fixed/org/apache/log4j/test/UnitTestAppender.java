/*
 * Copyright (C) The Apache Software Foundation. All rights reserved.
 *
 * This software is published under the terms of the Apache Software
 * License version 1.1, a copy of which has been included with this
 * distribution in the LICENSE.APL file.  */

package org.apache.log4j.test;

import org.apache.log4j.*;
import org.apache.log4j.spi.*;
import java.io.*;


public class UnitTestAppender {

  static org.apache.log4j.Category cat = Category.getInstance(UnitTestAppender.class);

  public void testAppender() {
    FileAppender f = null;
    try {
      f = new FileAppender(new TTCCLayout(), new FileWriter("myLog.txt"));
    } catch (Exception e ) {
      e.printStackTrace();
    }
    LoggingEvent event1 = new LoggingEvent("", cat, Priority.DEBUG, "message1", null);
    OtherThread ot = new OtherThread(f);
    ot.start();
    f.doAppend(event1);
    try {
      ot.join();
    } catch (Exception e ) {
      e.printStackTrace();
    }
  }
  
  static class OtherThread extends Thread {
    private final Appender _appender;
    public OtherThread(Appender f) {
      _appender = f;
    }

    public void run() {
      try{
        Thread.sleep(1000);
      } catch (Exception e) {
        e.printStackTrace();
      }
      _appender.close();
    }
  }
  
  public static void main (String args[]) {
    UnitTestAppender t = new UnitTestAppender();
    t.testAppender();
    }
}
