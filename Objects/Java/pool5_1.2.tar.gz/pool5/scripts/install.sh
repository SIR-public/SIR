#!/bin/sh

if [ ! ${experiment_root} ]
then
    echo "experiment_root is unset in the shell"
    echo "please set experiment_root to point to your experiment directory"
    echo "see README for more information:"
    exit 2
fi

if test $# -ne 1
	then \
		echo Usage:
		echo install.sh comp_dir 
		echo comp_dir: orig
		exit 0
fi

subject_dir=${experiment_root}/pool5
echo removing old files
rm -f -r ${subject_dir}/source/*
rm -f ${subject_dir}/outputs/*

if test $1 = "orig"
then
     echo copying files for $1 version
     mkdir -p ${subject_dir}/source/$1
     cp -r ${subject_dir}/versions.alt/$1/* ${subject_dir}/source/$1
else
    echo orig is the only option currently available
    exit 0
fi
cd ${subject_dir}/source

echo compiling application
echo "java home"
echo $JAVA_HOME
find . -name "*.java" | xargs javac -deprecation -source 1.5 > /dev/null
