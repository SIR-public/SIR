#!/bin/sh

if test $# -ne 2 
	then \
		echo install_seeded.sh seeded component_version
		exit 0
fi

curr_dir=${experiment_root}/siena/scripts
compdir=${curr_dir}/../versions.alt/component/$1/v$2
rm -f -r ${curr_dir}/../source/*

cp ${compdir}/* ${curr_dir}/../source/.

cp ${curr_dir}/../versions.alt/application/* ${curr_dir}/../source/.
cd ${curr_dir}/../source
rm -f HierarchyDejavu.java
rm -f HierarchyDejavu_2.java

cp ${curr_dir}/tool/EqualizeLineNumbers* .
find ./ -name "*.cpp" >  __tmpfile
while read LINE
do
	java EqualizeLineNumbers $LINE 0 `echo $LINE | sed "s/\.cpp/\.java/"` 
done < __tmpfile
rm __tmpfile

make

cd ${curr_dir}/../testdrivers
rm -f *.java

if test $2 -lt 3 
	then \
		cp original/IntMult/IntMult_old.java original/IntMult.java
		cp original/*.java .
	else \
		cp original/IntMult/IntMult_new.java original/IntMult.java
		cp original/*.java .
fi

make
cd ..
tmp_dir=`pwd`
mkdir -p ${tmp_dir}/source/testdrivers/siena
cp testdrivers/siena/* ${tmp_dir}/source/testdrivers/siena/.
