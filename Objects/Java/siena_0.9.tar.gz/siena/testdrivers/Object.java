// -*- Java -*-
//
//  This file is part of Siena, a wide-area event notification system.
//  See http://www.cs.colorado.edu/serl/siena/
//
//  Author: Antonio Carzaniga <carzanig@cs.colorado.edu>
//  See the file AUTHORS for full details. 
//
//  Copyright (C) 1998-1999 University of Colorado
//
//  This program is free software; you can redistribute it and/or
//  modify it under the terms of the GNU General Public License
//  as published by the Free Software Foundation; either version 2
//  of the License, or (at your option) any later version.
//
//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.
//
//  You should have received a copy of the GNU General Public License
//  along with this program; if not, write to the Free Software
//  Foundation, Inc., 59 Temple Place, Suite 330, Boston, MA 02111-1307,
//  USA, or send email to serl@cs.colorado.edu.
//
//
// $Id: Object.java,v 1.1 2000/10/31 01:21:29 carzanig Exp $
//

//
// this is an example of an object of interest, that is, a producer of
// notifications
//
package siena;
import siena.*;

class SimpleNot implements Notifiable {
    Siena siena;

    public SimpleNot(Siena s) {
	siena = s;
    }

    public void notify(Event e) {
	System.out.println("local notifiable: " + e.toString());
	 try {
	     siena.unsubscribe(this);
	 } catch (SienaException ex) {
	     ex.printStackTrace();
	 }
    }

    public void notify(Event [] s) { 
    }
}

public class Object {
    public static void main(String[] args) {
	    HierarchicalDispatcher siena;
	    Dejavu d = new Dejavu();
	try {
	    siena = new HierarchicalDispatcher();

	    switch(args.length) {
	    case 1: siena.setMaster(args[0]); 
	    case 0: break;
	    default:
		System.err.println("Usage: Object [server-uri]");
//		System.exit(1);
	    }
	    
	    Filter f = new Filter();
	    f.addConstraint("name", AttributeConstraint.SF, "");
	    
	    siena.subscribe(f, new SimpleNot(siena));
	    
	    Event e = new Event();
	    e.putAttribute("name", "Antonio");
	    e.putAttribute("age", 30);
	    e.putAttribute("nationality", "italian");

	    System.out.println("publishing " + e.toString());
	    try {
		Thread.sleep(5000);
		siena.publish(e);
	    } catch (SienaException ex) {
		System.err.println("Siena error:" + ex.toString());
	    }
	    System.out.println("shutting down.");
	    siena.shutdown();
	} catch (Exception ex) {
	    ex.printStackTrace();
//	    System.exit(1);
	}
    }
}
