#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out6
#
echo "Test 6"
echo "starting up server..."
#
#$JAVA siena.StartServer -port 7000 -id senp://:7000 &
#server=$!
#
#sleep 3
#
echo "Testing SubPub ..."
#
#$JAVA siena.SubPub senp://:7000 < in  > outputs/test.out6 2>&1 &
$JAVA siena.SubPub senp://:7000 <in > outputs/test.out6 2>&1 & 
client=$!
#
echo "client"
echo $client
echo "sleeping"
sleep 10

#kill $server
kill $client
#
#if diff out.txt modified; then
#        echo test_6 >> test.cases
#        exit 0
#else
#        exit 1
#fi
#
