#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out35
#
echo "Test 35"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing IntMult ..."
#
$JAVA siena.IntMult senp://:7000 100 >> outputs/test.out35 & 
client=$!
#
sleep 360

kill $server
kill $client
#
if diff out.txt modified; then
        echo test_35 >> test.cases
        exit 0
else
        exit 1
fi

