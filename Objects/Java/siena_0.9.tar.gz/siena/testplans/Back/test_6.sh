#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out6
#
echo "Test 6"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing SubPub ..."
#
$JAVA siena.SubPub senp://:7000 >> outputs/test.out6 2>&1 <<EOF 
filter
1
senp{x=0} filter {x = 20 y =30 z=10}
event
1
senp{x=0} event {v=20.5 y=35 z=10}
EOF
#
sleep 10

kill $server
#kill $client
#
if diff out.txt modified; then
        echo test_6 >> test.cases
        exit 0
else
        exit 1
fi

