#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out7
#
echo "Test 7"
echo "starting up server..."
#
#$JAVA siena.StartServer -port 7000 -id senp://:7000 &
#server=$!
#
sleep 3
#
echo "Testing SubPub ..."
#
#$JAVA siena.SubPub senp://:7000 >> outputs/test.out7 2>&1 <<EOF 
$JAVA siena.SubPub senp://:7000 >> outputs/test.out7 2>&1 <<EOF
filter
2
senp{x=0} filter {x = 20 y =30 z=10}
senp{x=1} filter {w=20.5 x = 20 y =30 z=10 v="milk"}
event
1
senp{x=0} event {w=30 x=20 y=20 z=10}
EOF 
#
echo "sleeping"
sleep 10
echo "end sleeping"
#kill $server
#kill $client
#
#if diff out.txt modified; then
#        echo test_7 >> test.cases
#        exit 0
#else
#        exit 1
#fi

