#!/bin/sh
i=1
while [ $i -le 574 ]; do
	filter.awk $1/test_$i.sh > test_$i.sh
	i=`expr ${i} + 1`
done
