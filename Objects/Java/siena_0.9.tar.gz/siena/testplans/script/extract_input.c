/**** This program extracts input strings from siena test scripts *******/
/**** Input strings are between EOF and EOF  ****************************/
#include <stdio.h>
#include <ctype.h>

FILE   *infile, *outfile;
char   token[100];
int    id, fsm_id;
int    in=0, out=1;

main(int argc, char *argv[])
{

int i;

	// file open and read 
	if(argc != 3){
		printf("Usage: parser <file1> <outfile>\n");
		exit(-1);
	}
	infile = fopen(argv[1], "rt"); 	

	if (infile == NULL){
		printf("\nCannot find %s\n", argv[1]);
		exit(-1);
	}
	
	outfile = fopen(argv[2], "wt");
	if (outfile == NULL){
		printf("\nCannot open %s\n", argv[2]);
		exit(-1);
	}

        lex(infile, token);
        while(strcmp(token, "eof")!=0)
        {
            if(strcmp(token, "EOF")==0){
                lex(infile, token);
		if(strcmp(token,"\n") ==0)
                    lex(infile, token);
    		while(strcmp(token,"EOF") !=0){
            	    fprintf(outfile,"%s", token);
                    lex(infile, token);
            	}
		if(strcmp(token, "EOF")==0)
		    break;
	    }
                lex(infile, token);
	}
	fclose(infile);
	fclose(outfile);
}

lex(FILE* file1, char *lexem)
{
int    i, j, k, c;

        for(i=0;i<100;i++)
            lexem[i]='\0';

        c=getc(file1);
        if(c == -1){
          strcpy(lexem, "eof");
        //   printf("eof %s %d\n", lexem, c);
        }
//        while(isspace(c)) { c=getc(file1); continue; }
        i=0;
        if(c=='"' || c==':' || c==',' || c=='[' || c==']' || c=='|' ||  c=='-' ||
	   c=='(' || c==')' || isspace(c)|| c=='{' || c=='}' || c=='<' ||  c=='>' ||
	   c=='.' || c=='_' || c=='$' || c=='=' || c=='!' || c=='?' || c=='&' ||
	   c=='+' || c=='*' || c=='/' || c=='%' || c=='#' || c=='^'){
           lexem[i] = c;
        }

        if(isdigit(c) || isalpha(c)){
            while(isdigit(c) || isalpha(c)){
                lexem[i]=c;
                i++;
                c=getc(file1);
            }
            if(c!= -1)
                c=ungetc(c, file1);
        }
}
