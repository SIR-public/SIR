#!/usr/bin/awk -f
{for(i=1;i<=NF;i++) 
if($i=="if")
	exit 1;
}
{for(i=1;i<=NF;i++) 
if($i!="if"){
if(i!=NF)
printf("%s ",$i);
else
printf("%s",$i);
}
printf("\n");}
