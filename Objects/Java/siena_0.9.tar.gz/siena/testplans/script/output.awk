#!/usr/bin/awk -f
#{for(i=1;i<=NF;i++) 
#if($i!="EOF")
#	exit 1;
#}
{for(i=1;i<=NF;i++) 
if($i=="filter" || $i=="event" || $i == "1" || $i== "2"){
{for(i=1;i<=NF;i++) 
printf("%s ",$i);}
#if($i=="EOF")
#	exit 1;
}
printf("\n");}
