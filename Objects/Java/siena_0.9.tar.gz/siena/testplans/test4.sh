#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out4
#
echo "Test 4"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing SubPub ..."
#
#$JAVA siena.SubPub senp://:7000 >> outputs/test.out4 <<EOF -- error on the terminal 
$JAVA siena.SubPub senp://:7000 <in.4 > outputs/test.out4  &
client=$!
#
sleep 10

kill $server
kill $client
#
if diff out.txt modified; then
        echo test_4 >> test.cases
        exit 0
else
        exit 1
fi

