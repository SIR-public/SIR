#!/bin/sh
#
. ./config.sh
#
echo "Test 2"
#
echo "starting up server 1(parent)..."
#
$JAVA siena.StartServer -port 7000 &
server1=$!
#
sleep 2
#
echo "starting up server 2(the first child)..."
#
$JAVA siena.StartServer -port 2000 -master senp://:7000 > ../outputs/test.out2 &
server2=$!
#
sleep 5
#
echo "starting up server 3(the second child)..."
#
$JAVA siena.StartServer -port 3000 -master senp://:7000 > ../outputs/test.out2 &
server3=$!
#
sleep 5
#
kill $server1
kill $server2
kill $server3
#
