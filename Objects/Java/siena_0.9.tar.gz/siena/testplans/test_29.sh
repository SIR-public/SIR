#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out29
#
echo "Test 29"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 0 not_unsub >> outputs/test.out29 2>&1 <<EOF
filter
senp{x=0} filter {x != 20}
EOF
#
sleep 10

kill $server
#kill $client
#
