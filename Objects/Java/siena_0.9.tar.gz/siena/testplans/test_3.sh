#!/bin/sh
#
. ./config.sh
#
echo "Test 3"
#
echo "starting up server 1(parent)..."
#
$JAVA siena.StartServer -port 7000 &
server1=$!
#
sleep 2
#
echo "starting up server 2(the child of server 1)..."
#
$JAVA siena.StartServer -port 3000 -master senp://:7000 &
server2=$!
#
sleep 5
#
echo "starting up server 3(the child of server 2)..."
#
$JAVA siena.StartServer -port 2000 -master senp://:3000 &
server3=$!
#
sleep 5
#
kill $server1
kill $server2
kill $server3
#
