#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out31
#
echo "Test 31 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 >> outputs/test.out31 2>&1
client=$!
#
sleep 10

kill $server
kill $client
#
