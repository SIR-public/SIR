#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out32
#
echo "Test 32 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 x 2 30 x 1 20 not_unsub>> outputs/test.out32 &
client=$!
#
sleep 10

kill $server
kill $client
#
