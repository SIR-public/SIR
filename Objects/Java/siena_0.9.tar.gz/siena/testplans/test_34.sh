#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out34
#
echo "Test 34"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing IntMult ..."
#
$JAVA siena.IntMult senp://:7000 5 >> outputs/test.out34 &
client=$!
#
sleep 20

kill $server
kill $client
#
