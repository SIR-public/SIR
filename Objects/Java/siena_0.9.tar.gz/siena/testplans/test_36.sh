#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out36
#
echo "Test 36 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing InterestedParty ..."

$JAVA siena.InterestedParty senp://:7000 value 1 30 value 1 30 not_unsub >> outputs/test.out36 &
client=$!
#
sleep 10

kill $server
kill $client
#
