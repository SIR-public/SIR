#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out37
#
echo "Test 37 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing InterestedParty ..."

$JAVA siena.InterestedParty senp://:7000 value 1 30 value 1 30 unsub >> outputs/test.out37 &
client=$!
#
sleep 10

kill $server
kill $client
#
