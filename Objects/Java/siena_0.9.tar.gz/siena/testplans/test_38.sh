#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out38
#
echo "Test 38 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing InterestedParty ..."

$JAVA siena.InterestedParty senp://:7000 value 3 30 color i9 white not_unsub >> outputs/test.out38 &
client=$!
#
sleep 10

kill $server
kill $client
#
