#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out39
#
echo "Test 39 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing InterestedParty ..."

$JAVA siena.InterestedParty senp://:7000 value 3 30 color 9 white unsub >> outputs/test.out39 &
client=$!
#
sleep 10

kill $server
kill $client
#
