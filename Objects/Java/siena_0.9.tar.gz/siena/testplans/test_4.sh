#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out4
#
echo "Test 4"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7777 -id senp://:7777 2>&1 > tmp &
#$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
echo Receiver
$JAVA Receiver 7000 > receive.out &
rpid=$!
sleep 3
#
echo "Testing SubPub ..."
#
#$JAVA -i siena.SubPub senp://:7000 < ../inputs/in.4 > outputs/t4 2>&1 &
$JAVA siena.SubPub senp://:7777>> outputs/test.out4 2>&1 <<EOF
filter
1
senp{x=0} filter {x = 20 y =30 z=10}
event
2
senp{x=0} event {x=20}
senp{x=0} event {y=30 z=10}
EOF
#
sleep 6
echo Sender...
#$JAVA siena.Sender 500 < outputs/test.out4 > sender.log
$JAVA siena.Sender 500 <<EOF > sender.log
senp{ to="senp://:7777" method="SUB" handler="senp://:7000"} filter{ x =20 y =30 z =10}
EOF
cat <<EOF > test.expected
senp{version=1 method="PUB" id="siena3" to="c/1"} event{ x=1 y=1 ref=1}
EOF
#senp{ to="senp://:7777" method="SUB" handler="senp://:7000" id="c/1"}filter{x any}
echo kill server
kill $server
kill $rpid
#
