#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out41
#
echo "Test 41 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing InterestedParty ..."

$JAVA siena.InterestedParty senp://:7000 value 3 30 color 1 white value 5 10.5 range 9 5 unsub >> outputs/test.out41 &
client=$!
#
sleep 10

kill $server
kill $client
#
