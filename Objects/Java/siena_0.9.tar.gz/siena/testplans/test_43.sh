#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out43
#
echo "Test 43"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfInterest ..."
#
$JAVA siena.ObjectOfInterest senp://:7000 age 20 age 20 >> outputs/test.out43 &
client=$!
#
sleep 10

kill $server
kill $client
#
