#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out45
#
echo "Test 45"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfInterest ..."
#
$JAVA siena.ObjectOfInterest senp://:7000 age 20 weight 100 age 18 year 2001>> outputs/test.out45 &
client=$!
#
sleep 10

kill $server
kill $client
#
