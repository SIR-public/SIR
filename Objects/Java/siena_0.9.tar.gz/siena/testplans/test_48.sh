#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out48
#
echo "Test 48"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 A 13 B 23 C 100 D 0 >> outputs/test.out48 &
client=$!
#
sleep 10

kill $server
kill $client
#
