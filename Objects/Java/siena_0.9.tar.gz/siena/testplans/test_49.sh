#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out49
#
echo "Test 49"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 A 13 B 23 C 100 D 0 E 50 F 34 >> outputs/test.out49 &
client=$!
#
sleep 10

kill $server
kill $client
#
