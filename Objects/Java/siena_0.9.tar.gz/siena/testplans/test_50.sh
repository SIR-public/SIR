#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out50
#
echo "Test 50"
echo "starting up server..."
#
$JAVA -port 10000 -tl 10 siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 A orange B apple >> outputs/test.out50 &
client=$!
#
sleep 10

echo kill server
#kill $server
echo kill client
#kill $client
#
