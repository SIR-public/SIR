#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out51
#
echo "Test 51"
echo "starting up server..."
#
$JAVA -port 10000 siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 A orange B apple A orange B apple >> outputs/test.out51 &
client=$!
#
sleep 10

kill $server
kill $client
#
