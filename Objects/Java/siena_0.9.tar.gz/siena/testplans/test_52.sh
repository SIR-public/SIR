#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out52
#
echo "Test 52"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 A orange B apple C plum D peach >> outputs/test.out52 &
client=$!
#
sleep 10

kill $server
kill $client
#
