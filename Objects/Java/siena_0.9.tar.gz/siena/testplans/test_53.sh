#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out53
#
echo "Test 53"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 A orange B apple C plum D peach E grape F tomato >> outputs/test.out53 &
client=$!
#
sleep 10

kill $server
kill $client
#
