#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out54
#
echo "Test 54"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 A 100.0 B 10 >> outputs/test.out54 &
client=$!
#
sleep 10

kill $server
kill $client
#
