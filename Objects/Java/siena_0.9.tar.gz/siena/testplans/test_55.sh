#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out55
#
echo "Test 55"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 false boolean weight 100 false boolean weight 100 >> outputs/test.out55 &
client=$!
#
sleep 10

kill $server
kill $client
#
