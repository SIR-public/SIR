#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out56
#
echo "Test 56"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 false boolean weight 100.5 name Ann age 20 >> outputs/test.out56 &
client=$!
#
sleep 10

kill $server
kill $client
#
