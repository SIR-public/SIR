#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out57
#
echo "Test 57"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfMultiple ..."
# four arguments for each notification
$JAVA siena.ObjectOfMultiple senp://:7000 name Bob weight 100.5 name Ann age 20 name John country USA >> outputs/test.out57 &
client=$!
#
sleep 10

kill $server
kill $client
#
