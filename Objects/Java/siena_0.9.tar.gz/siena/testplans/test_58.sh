#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out58
#
echo "Test 58 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
# args: port_no, # of attributes, [name, operation, value]+, unsub/not_sub
$JAVA siena.Interest senp://:7000 1 value 1 30 not_unsub >> outputs/test.out58 &
client=$!
#
sleep 10

kill $server
kill $client
#
