#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out59
#
echo "Test 59 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 1 value 1 30 unsub >> outputs/test.out59 &
client=$!
#
sleep 10

kill $server
kill $client
#
