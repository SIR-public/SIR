#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out60
#
echo "Test 60 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 1 value 1 30 unsub_nofilter >> outputs/test.out60 &
client=$!
#
sleep 10

kill $server
kill $client
#
