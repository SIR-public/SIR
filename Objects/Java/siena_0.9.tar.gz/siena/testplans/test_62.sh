#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out62
#
echo "Test 62 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 2 value 1 30 price 1 40 unsub >> outputs/test.out62 &
client=$!
#
sleep 10

kill $server
kill $client
#
