#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out63
#
echo "Test 63 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 2 value 1 30 price 1 40 unsub_nofilter >> outputs/test.out63 &
client=$!
#
sleep 10

kill $server
kill $client
#
