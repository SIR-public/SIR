#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out65
#
echo "Test 65 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 1 value 3 30 unsub >> outputs/test.out65 &
client=$!
#
sleep 10

kill $server
kill $client
#
