#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out66
#
echo "Test 66 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 1 value 3 30 unsub_nofilter >> outputs/test.out66 &
client=$!
#
sleep 10

kill $server
kill $client
#
