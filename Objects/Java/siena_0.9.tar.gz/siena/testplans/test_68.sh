#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out68
#
echo "Test 68 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 2 value 3 30 price 3 40 unsub >> outputs/test.out68 &
client=$!
#
sleep 10

kill $server
kill $client
#
