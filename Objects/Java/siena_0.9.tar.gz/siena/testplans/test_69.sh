#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out69
#
echo "Test 69 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 2 value 3 30 price 3 40 unsub_nofilter >> outputs/test.out69 &
client=$!
#
sleep 10

kill $server
kill $client
#
