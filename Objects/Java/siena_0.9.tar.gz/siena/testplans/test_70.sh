#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out70
#
echo "Test 70"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 country 1 USA name 1 John not_unsub >> outputs/test.out70 &
client=$!
#
sleep 10

kill $server
kill $client
#
