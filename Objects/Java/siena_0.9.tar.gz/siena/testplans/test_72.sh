#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out72
#
echo "Test 72 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 2 country 1 USA name 1 John unsub_nofilter >> outputs/test.out72 &
client=$!
#
sleep 10

kill $server
kill $client
#
