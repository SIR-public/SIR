#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out74
#
echo "Test 74"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 value1 3 10.55 value2 3 23.45 unsub >> outputs/test.out74 &
client=$!
#
sleep 10

kill $server
kill $client
#
