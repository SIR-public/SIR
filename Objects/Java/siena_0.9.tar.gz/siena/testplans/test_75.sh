#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out75
#
echo "Test 75"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 value1 3 10.55 value2 3 23.45 unsub_nofilter >> outputs/test.out75 &
client=$!
#
sleep 10

kill $server
kill $client
#
