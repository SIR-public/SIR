#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out76
#
echo "Test 76"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 x 1 10 y 3 20 not_unsub >> outputs/test.out76 &
client=$!
#
sleep 10

kill $server
kill $client
#
