#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out77
#
echo "Test 77 "
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."

$JAVA siena.Interest senp://:7000 2 value 4 30 price 3 40 unsub >> outputs/test.out77 &
client=$!
#
sleep 10

kill $server
kill $client
#
