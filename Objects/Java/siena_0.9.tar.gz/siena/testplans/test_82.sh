#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out82
#
echo "Test 82"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 price 3 100.50 item_no 3 100 not_unsub >> outputs/test.out82 &
client=$!
#
sleep 10

kill $server
kill $client
#
