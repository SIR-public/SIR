#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out83
#
echo "Test 83"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 price 3 100.50 item_no 3 100 unsub >> outputs/test.out83 &
client=$!
#
sleep 10

kill $server
kill $client
#
