#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out86
#
echo "Test 86"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 2 price 3 100.50 item 1 bag unsub >> outputs/test.out86 &
client=$!
#
sleep 10

kill $server
kill $client
#
