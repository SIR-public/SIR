#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out94
#
echo "Test 94"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 not_unsub >> outputs/test.out94 2>&1 <<EOF
filter
senp{x=0} filter {x > 30 }
event
senp{x=1} event {x = 40 }
EOF
#
sleep 10

kill $server
#kill $client
#
