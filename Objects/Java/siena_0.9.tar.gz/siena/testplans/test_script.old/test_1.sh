#!/bin/sh
#
. ./config.sh
#
echo "Test 1"
#
echo "starting up server 1(parent)..."
#
$JAVA siena.StartServer -port 7000 &
server1=$!
#
sleep 3
#
echo "starting up server 2(child)..."
#
$JAVA siena.StartServer -port 2000 -master senp://:7000 &
server2=$!
#
sleep 5
#
kill $server1
kill $server2
#
