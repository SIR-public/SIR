#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out10
#
echo "Test 10"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfInterest ..."
#
$JAVA siena.ObjectOfInterest senp://:7000 ?n~am*e* John >> outputs/test.out10 &
client=$!
#
sleep 10

kill $server
#kill $client
#
