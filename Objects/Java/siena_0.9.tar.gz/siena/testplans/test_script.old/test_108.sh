#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out108
#
echo "Test 108"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 unsub_nofilter >> outputs/test.out108 2>&1 <<EOF
filter
senp{x=0} filter {value > 13.45 price != 150.34}
event
senp{x=1} event {x = 30 }
EOF
#
sleep 10

kill $server
#kill $client
#
