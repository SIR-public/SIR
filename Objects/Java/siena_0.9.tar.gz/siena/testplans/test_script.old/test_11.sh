#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out11
#
echo "Test 11"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfInterest ..."
#
$JAVA siena.ObjectOfInterest senp://:7000 name John >> outputs/test.out11 &
client=$!
#
sleep 10

kill $server
kill $client
#
