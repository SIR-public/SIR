#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out116
#
echo "Test 116"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 unsub >> outputs/test.out116 2>&1 <<EOF
filter
senp{x=0} filter {status = true price > 2000.00}
event
senp{x=1} event {x = 30 }
EOF
#
sleep 10

kill $server
#kill $client
#
