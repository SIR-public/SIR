#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out12
#
echo "Test 12"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfInterest ..."
#
$JAVA siena.ObjectOfInterest senp://:7000 weight 180.50 >> outputs/test.out12 &
client=$!
#
sleep 10

kill $server
kill $client
#
