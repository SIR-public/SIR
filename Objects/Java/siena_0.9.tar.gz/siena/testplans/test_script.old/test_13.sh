#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out13
#
echo "Test 13"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfInterest ..."
#
$JAVA siena.ObjectOfInterest senp://:7000 false booleanValue >> outputs/test.out13 &
client=$!
#
sleep 10

kill $server
kill $client
#
