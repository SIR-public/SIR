#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out131
#
echo "Test 131"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub >> outputs/test.out131 2>&1 <<EOF
filter
senp{x=0} filter {item = "bag" stock = "yes"}
event
senp{x=1} event {item_no = 150}
senp{x=1} event {item_no = 150}
EOF
#
sleep 10

kill $server
#kill $client
#
