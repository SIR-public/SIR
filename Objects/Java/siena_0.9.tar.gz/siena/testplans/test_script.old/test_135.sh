#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out135
#
echo "Test 135"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub_nofilter >> outputs/test.out135 2>&1 <<EOF
filter
senp{x=0} filter {price > 120.50 discount > 10.00}
event
senp{x=1} event {item_no = 150}
senp{x=1} event {item_no = 150}
EOF
#
sleep 10

kill $server
#kill $client
#
