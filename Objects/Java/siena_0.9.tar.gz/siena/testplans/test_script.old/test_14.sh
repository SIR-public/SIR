#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out14
#
echo "Test 14"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectOfInterest ..."
#
$JAVA siena.ObjectOfInterest senp://:7000 >> outputs/test.out14 2>&1
client=$!
#
sleep 10

kill $server
kill $client
#
