#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out16
#
echo "Test 16"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectMultAtt ..."
#
$JAVA siena.ObjectMultAtt senp://:7000 5 >> outputs/test.out16 &
client=$!
#
sleep 10

kill $server
kill $client
#
