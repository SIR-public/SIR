#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out17
#
echo "Test 17"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing ObjectMultAtt ..."
#
$JAVA siena.ObjectMultAtt senp://:7000 100 >> outputs/test.out17 &
client=$!
#
sleep 100
#
kill $server
kill $client
#
