#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out174
#
echo "Test 174"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub_nofilter >> outputs/test.out174 2>&1 <<EOF
filter
senp{x=0} filter {item_no > 200 discount > 10.15}
event
senp{x=1} event {item_no = 150}
senp{x=1} event {stock = 100}
EOF
#
sleep 10

kill $server
#kill $client
#
