#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out184
#
echo "Test 184"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 3 not_unsub >> outputs/test.out184 2>&1 <<EOF
filter
senp{x=0} filter {item_no > 150}
event
senp{x=1} event {item_no = 160}
senp{x=1} event {stock = 100}
senp{x=1} event {demand = 20}
EOF
#
sleep 10

kill $server
#kill $client
#
