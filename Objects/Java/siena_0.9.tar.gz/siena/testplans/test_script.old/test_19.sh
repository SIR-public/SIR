#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out19
#
echo "Test 19"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 1 name 9 Ann not_unsub >> outputs/test.out19 &
client=$!
#
sleep 10

kill $server
kill $client
#
