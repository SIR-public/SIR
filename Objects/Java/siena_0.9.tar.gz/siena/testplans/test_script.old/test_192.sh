#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out192
#
echo "Test 192"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 3 unsub_nofilter >> outputs/test.out192 2>&1 <<EOF
filter
senp{x=0} filter {price = 90.11 discount = 5.6}
event
senp{x=1} event {demand = 20}
senp{x=1} event {stock = 110}
senp{x=1} event {item_no = 10}
EOF
#
sleep 10

kill $server
#kill $client
#
