#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out194
#
echo "Test 194"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 3 unsub >> outputs/test.out194 2>&1 <<EOF
filter
senp{x=0} filter {demand > 10 stock > 100}
event
senp{x=1} event {demand = 20}
senp{x=1} event {stock = 110}
senp{x=1} event {item_no = 10}
EOF
#
sleep 10

kill $server
#kill $client
#
