#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out20
#
echo "Test 20"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
#
$JAVA siena.Interest senp://:7000 1 value 2 30.25 not_unsub >> outputs/test.out20 &
client=$!
#
sleep 10

kill $server
kill $client
#
