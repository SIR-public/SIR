#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out21
#
echo "Test 21"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing Interest ..."
# args: port_num attr_num arg[2] relop arg[4] subscr_opt
$JAVA siena.Interest senp://:7000 1 true 1 booleanVal not_unsub >> outputs/test.out21 &
client=$!
#
sleep 10

kill $server
kill $client
#
