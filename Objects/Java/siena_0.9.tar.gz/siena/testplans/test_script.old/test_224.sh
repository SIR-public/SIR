#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out224
#
echo "Test 224"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 unsub >> outputs/test.out224 2>&1 <<EOF
filter
senp{x=0} filter {item_rate = 23.45 selling = 56.75}
event
senp{x=1} event {stock = 100 item_no = 10}
EOF
#
sleep 10

kill $server
#kill $client
#
