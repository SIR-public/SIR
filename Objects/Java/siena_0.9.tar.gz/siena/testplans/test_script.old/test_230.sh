#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out230
#
echo "Test 230"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 unsub >> outputs/test.out230 2>&1 <<EOF
filter
senp{x=0} filter {item_rate = 23.45 item_no = 10}
event
senp{x=1} event {stock = 100 item_no = 10}
EOF
#
sleep 10

kill $server
#kill $client
#
