#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out235
#
echo "Test 235"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 not_unsub >> outputs/test.out235 2>&1 <<EOF
filter
senp{x=0} filter {item_rate != 23.45 item_no > 7}
event
senp{x=1} event {stock = 100 item_no = 10}
EOF
#
sleep 10

kill $server
#kill $client
#
