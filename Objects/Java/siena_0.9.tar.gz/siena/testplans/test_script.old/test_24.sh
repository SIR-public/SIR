#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out24
#
echo "Test 24"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 0 not_unsub >> outputs/test.out24 2>&1 <<EOF
filter
senp{x=0} filter {x <= 30}
EOF
#
sleep 10

kill $server
#kill $client
#
