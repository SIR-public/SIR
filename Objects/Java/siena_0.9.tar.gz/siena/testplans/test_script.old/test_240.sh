#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out240
#
echo "Test 240"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub_nofilter >> outputs/test.out240 2>&1 <<EOF
filter
senp{x=0} filter {stock = 100}
event
senp{x=1} event {stock = 100 item_no = 10}
senp{x=1} event {stock = 100 item_no = 10}
EOF
#
sleep 10

kill $server
#kill $client
#
