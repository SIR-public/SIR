#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out247
#
echo "Test 247"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 not_unsub >> outputs/test.out247 2>&1 <<EOF
filter
senp{x=0} filter {stock > 95 item_no > 8}
event
senp{x=1} event {stock = 100 item_no = 10}
senp{x=1} event {stock = 100 item_no = 10}
EOF
#
sleep 10

kill $server
#kill $client
#
