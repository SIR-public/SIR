#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out275
#
echo "Test 275"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub >> outputs/test.out275 2>&1 <<EOF
filter
senp{x=0} filter {stock > 90}
event
senp{x=1} event {stock = 100 item_no = 10}
senp{x=1} event {stock = 100 price = 350}
EOF
#
sleep 10

kill $server
#kill $client
#
