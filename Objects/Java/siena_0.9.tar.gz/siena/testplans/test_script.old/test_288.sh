#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out288
#
echo "Test 288"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub_nofilter >> outputs/test.out288 2>&1 <<EOF
filter
senp{x=0} filter {price >= 320.45 tax <= 10.25}
event
senp{x=1} event {stock = 100 item_no = 10}
senp{x=1} event {stock = 100 price = 350}
EOF
#
sleep 10

kill $server
#kill $client
#
