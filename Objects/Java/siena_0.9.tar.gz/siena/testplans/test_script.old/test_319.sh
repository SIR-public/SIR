#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out319
#
echo "Test 319"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 3 not_unsub >> outputs/test.out319 2>&1 <<EOF
filter
senp{x=0} filter {item = soap stock = 100}
event
senp{x=1} event {stock = 100 item_no = 10}
senp{x=1} event {stock = 100 price = 200}
senp{x=1} event {stock = 100 demand = 50}
EOF
#
sleep 10

kill $server
#kill $client
#
