#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out331
#
echo "Test 331"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 not_unsub >> outputs/test.out331 2>&1 <<EOF
filter
senp{x=0} filter {item_no = 45 stock = 200}
event
senp{x=1} event {item = "soap" brand = "dial"}
EOF
#
sleep 10

kill $server
#kill $client
#
