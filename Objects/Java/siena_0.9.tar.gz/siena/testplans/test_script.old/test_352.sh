#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out352
#
echo "Test 352"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 not_unsub >> outputs/test.out352 2>&1 <<EOF
filter
senp{x=0} filter {brand > c price > 2.45}
event
senp{x=1} event {item = "soap" brand = "dial"}
EOF
#
sleep 10

kill $server
#kill $client
#
