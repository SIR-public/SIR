#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out354
#
echo "Test 354"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 1 unsub_nofilter >> outputs/test.out354 2>&1 <<EOF
filter
senp{x=0} filter {brand > c price > 2.45}
event
senp{x=1} event {item = "soap" brand = "dial"}
EOF
#
sleep 10

kill $server
#kill $client
#
