#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out381
#
echo "Test 381"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub_nofilter >> outputs/test.out381 2>&1 <<EOF
filter
senp{x=0} filter {item = "soap" price = 5.50 }
event
senp{x=1} event {item = soap brand = "dial"}
senp{x=1} event {item = soap brand = "dial"}
EOF
#
sleep 10

kill $server
#kill $client
#
