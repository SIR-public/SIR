#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out391
#
echo "Test 391"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 not_unsub >> outputs/test.out391 2>&1 <<EOF
filter
senp{x=0} filter {item_no = 100 price = 2}
event
senp{x=1} event {item = "soap" brand = "dial"}
senp{x=1} event {item_no = 100 price = 2}
EOF
#
sleep 10

kill $server
#kill $client
#
