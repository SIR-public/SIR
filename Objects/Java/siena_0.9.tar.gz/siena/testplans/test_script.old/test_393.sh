#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out393
#
echo "Test 393"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing OpTest ..."
#
$JAVA siena.OpTest senp://:7000 2 unsub_nofilter >> outputs/test.out393 2>&1 <<EOF
filter
senp{x=0} filter {item_no = 100 price = 2}
event
senp{x=1} event {item = "soap" brand = "dial"}
senp{x=1} event {item_no = 100 price = 2}
EOF
#
sleep 10

kill $server
#kill $client
#
