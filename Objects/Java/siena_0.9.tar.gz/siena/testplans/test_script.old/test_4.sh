#!/bin/sh
#
. ./config.sh
#
rm -f outputs/test.out4
#
echo "Test 4"
echo "starting up server..."
#
$JAVA siena.StartServer -port 7000 -id senp://:7000 &
server=$!
#
sleep 3
#
echo "Testing SubPub ..."
#
$JAVA siena.SubPub senp://:7000 >> ../outputs/test.out4 2>&1 <<EOF
filter
1
senp{x=0} filter {x = 20 y =30 z=10}
event
2
senp{x=0} event {x=20}
senp{x=0} event {y=30 z=10}
EOF
#
sleep 10

kill $server
#kill $client
#
