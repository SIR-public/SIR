package idiscovery.examples;

import java.util.Scanner;

//Jeff Offutt -- Java version Feb 2003
//The old standby: classify triangles
//Figures 3.2 and 3.3 in the book.

public class trityp
{
    private static String[] triTypes = { "",    /* Ignore 0 */
        "scalene", "isosceles", "equilateral", "not a valid triangle"};
    private static String instructions = "This is the ancient TriTyp program.\nEnter three integers that represent the lengths of the sides of a triangle.\nThe triangle will be categorized as either scalene, isosceles, equilateral\nor invalid\n";

    public static void main (String[] argv)
    {  // Driver program for trityp
        int A, B, C;
        int T;

        System.out.println (instructions);
        Scanner input = new Scanner(System.in);
        System.out.println ("Enter side 1: ");
        A = input.nextInt();
        System.out.println ("Enter side 2: ");
        B = input.nextInt();
        System.out.println ("Enter side 3: ");
        C = input.nextInt();
        input.close();

        System.out.print("A=" + A + " B=" + B + " C=" + C);
        T = Triang (A, B, C);
        System.out.println(" T=" + T);
        System.out.println ("Result is: " + triTypes [T]);

        // assertions below added to express correctness -- see
        // Yang et al.'s ICSE 2014 paper on iProperty for details

        /*A0*/assert T != 0;

        /*A1*/assert A <= 0 || B <= 0 || C <= 0 ? T == 4 : true;

        /*A2*/assert A + B <= C ? T == 4 : true;
        /*A3*/assert A + C <= B ? T == 4 : true;
        /*A4*/assert B + C <= A ? T == 4 : true;

        /*A5*/assert A == B && B == C && A > 0 ? T == 3 : true;

        /*A6*/assert A == B && A != C && C < A + B && C > 0 ? T == 2 : true;
        /*A7*/assert A == C && A != B && B < A + C && B > 0 ? T == 2 : true;
        /*A8*/assert B == C && B != A && A < B + C && A > 0 ? T == 2 : true;

        /*A9*/assert A != B && A != C && B != C && A + B > C && A + C > B && B + C > A ? T == 1 : true;
    }

    // ====================================
    // The main triangle classification method
    private static int Triang (int Side1, int Side2, int Side3)
    {
        int tri_out;
        // tri_out is output from the routine:
        //    Triang = 1 if triangle is scalene
        //    Triang = 2 if triangle is isosceles
        //    Triang = 3 if triangle is equilateral
        //    Triang = 4 if not a triangle
        // After a quick confirmation that it's a legal
        // triangle, detect any sides of equal length
        if (Side1 <= 0 || Side2 <= 0 || Side3 <= 0)
        {
            tri_out = 4;
            return (tri_out);
        }

        tri_out = 0;
        if (Side1 == Side2)
            tri_out = tri_out + 1;
        if (Side1 == Side3)
            tri_out = tri_out + 2;
        if (Side2 == Side3)
            tri_out = tri_out + 3;
        if (tri_out == 0)
        {  // Confirm it's a legal triangle before declaring
            // it to be scalene

            if (Side1+Side2 <= Side3 || Side2+Side3 <= Side1 ||
                    Side1+Side3 <= Side2)
                tri_out = 4;
            else
                tri_out = 1;
            return (tri_out);
        }

        /* Confirm it's a legal triangle before declaring  */
        /* it to be isosceles or equilateral  */

        if (tri_out > 3)
            tri_out = 3;
        else if (tri_out == 1 && Side1+Side2 > Side3)
            tri_out = 2;
        else if (tri_out == 2 && Side1+Side3 > Side2)
            tri_out = 2;
        else if (tri_out == 3 && Side2+Side3 > Side1)
            tri_out = 2;
        else
            tri_out = 4;
        return (tri_out);
    } // end Triang
}
