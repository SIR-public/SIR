

if test $# -ne 5
then echo "Usage: ${0} <prog> <version start> <number of versions> <test universe file> <fault matrix file>"
     exit 1
fi

prog=${1}
subject_dir=${experiment_root}/subjects/${prog}
faults_file_name=FaultSeeds.h
fault_start=1
ver_start=${2}
vers=${3}
fault_matrix_prefix=${subject_dir}/info/
fault_matrix_name=${5}

universe_path=${subject_dir}/testplans.alt/
universe_name=${4}
universe_multiple=0
exec_path=${subject_dir}/source/
source_orig_path_prefix=${subject_dir}/versions.alt/versions.orig/
source_seeded_path_prefix=${subject_dir}/versions.alt/versions.seeded/

get_data_for_fault_matrix.sh ${subject_dir} ${prog} ${fault_start} \
    ${faults_file_name} ${ver_start} ${vers} ${universe_path} ${universe_name} \
    ${universe_multiple} \
    ${exec_path} ${fault_matrix_prefix} ${fault_matrix_name} \
    ${source_orig_path_prefix} ${source_seeded_path_prefix}
