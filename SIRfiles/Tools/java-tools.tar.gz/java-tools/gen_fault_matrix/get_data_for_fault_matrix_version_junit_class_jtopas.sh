if test $# -ne 11 
then echo "Usage: ${0} <subject_dir> <subject> <fault dir> <faults file> <fault number> <version> <universe> <all diffs> <exec path> <stored> <classpath>"
     exit 1
fi

script=`gen_temp_file F`
diffs=`gen_temp_file F`
ascript=`gen_temp_file F`
subject_dir=${1}
executable=${2}
fault_dir=${3}
faults_file=${4}
fault_number=${5}
version=${6}
universe=${7}
all_diffs=${8}
exec_path=${9}
shift
stored=${9}
shift
classpath=${9}

echo Compiling faulty version

current_dir=`pwd`
cd ${exec_path}
cp orig_FaultSeeds.h FaultSeeds.h

# Remove .class files
find ./ -name "*.class" >  __tmpfile
while read LINE
do
        rm -f $LINE
done < __tmpfile
rm __tmpfile

cp ${current_dir}/EqualizeLineNumbers*.class ${exec_path}/. 
#echo CLASSPATH $CLASSPATH
# turn off previous fault
find ./ -name "*.cpp" >  __tmpfile
while read LINE
do
        java EqualizeLineNumbers $LINE 0 `echo $LINE | sed "s/\.cpp/\.java/"`
done < __tmpfile
rm __tmpfile

cp FaultSeeds.h tmp_fault
sed "${fault_number},${fault_number}s/\/\* //" tmp_fault > Fault.h
sed "${fault_number},${fault_number}s/ \*\///" Fault.h > ${fault_dir}
rm Fault.h tmp_fault
find ./ -name "*.cpp" >  __tmpfile
while read LINE
do
        gcc -E -P $LINE > `echo $LINE | sed "s/\.cpp/\.java/"`
done < __tmpfile
rm __tmpfile

#############################################################################
##   The following line compiles java files after turning one fault on     ##   
##   This works for jtopas and Siena.                                      ##
##   If you are working on different subject, then adjust this line for it.## 
#############################################################################
make
cd ${subject_dir}/scripts
touch ${all_diffs}
rm -f -r ${subject_dir}/outputs
mkdir -p ${subject_dir}/outputs
t_num=`cat ${subject_dir}/${universe} | wc -l`
t_num=`expr $t_num - 1`
echo t_num $t_num
scriptR${version}_prev.cls
cd ${current_dir}

n=0
while (test $n -lt ${t_num})
    do
	exp=0
	nplus=`expr $n + 1`
	current_dir=`pwd`
	cd ${current_dir}
        if (cmp -s ${subject_dir}/outputs/t${nplus} ${subject_dir}/outputs.alt/v${version}/t${nplus}) then
               	exp=0
	else
		exp=1
        fi
	echo testNumber $n
        echo "Version:${fault_number} Test:${n} Exposed:${exp}" >> ${all_diffs}
	n=`expr $n + 1`
    done

rm -f ${script} ${diffs} ${ascript}

echo Done for fault ${fault_number} and version ${version}
