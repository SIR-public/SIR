BEGIN {}
  {print $n;}
END {}
