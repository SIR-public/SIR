package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoParser1_vw_v1Tests extends TestCase {

	public void test0() throws Exception {
		//Parser_vw_v1_1.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_1.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" java.lang.NullPointerException\n\tat net.n3.nanoxml.XMLWriter.write(XMLWriter.java:109)\n\tat net.n3.nanoxml.XMLWriter.write(XMLWriter.java:91)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:53)\n");
	}

	public void test1() throws Exception {
		//Parser_vw_v1_2.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_2.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<BAR/>\n");
	}

	public void test2() throws Exception {
		//Parser_vw_v1_3.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_3.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO>\n    <BAR/>\n    <BAR x=\"1\"/>\n    <BAR x=\"1\" y=\"2\"/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n    <BAR/>\n    <BAR x=\"1\">blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

	public void test3() throws Exception {
		//Parser_vw_v1_4.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_4.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" java.io.IOException: Unexpected EOF\n\tat net.n3.nanoxml.StdXMLReader.read(StdXMLReader.java:354)\n\tat net.n3.nanoxml.XMLUtil.skipWhitespace(XMLUtil.java:346)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:423)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test4() throws Exception {
		//Parser_vw_v1_5.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_5.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 15: Closing tag does not match opening tag: `FOO' != `BAR'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test5() throws Exception {
		//Parser_vw_v1_6.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_6.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 10: Closing tag does not match opening tag: `BAR' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test6() throws Exception {
		//Parser_vw_v1_7.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_7.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO>\n    <BAR/>\n    <BAR x=\"1\"/>\n    <BAR x=\"1\" y=\"2\"/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n        <BAR/>\n        blah\n    </BAR>\n    <BAR x=\"1\">blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

	public void test7() throws Exception {
		//Parser_vw_v1_8.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_8.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<xml>\n    <BAR/>\n    <BAR x=\"1\"/>\n    <BAR x=\"1\" y=\"2\"/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n    <BAR>blah</BAR>\n    <BAR x=\"1\">blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</xml>\n");
	}

	public void test8() throws Exception {
		//Parser_vw_v1_9.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_9.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO>\n    <BAR/>\n    <BAR/>\n    <BAR/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n    <BAR>blah</BAR>\n    <BAR>blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

	public void test9() throws Exception {
		//Parser_vw_v1_10.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_10.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 3: Expected: delimited string\n\tat net.n3.nanoxml.XMLUtil.errorExpectedInput(XMLUtil.java:450)\n\tat net.n3.nanoxml.XMLUtil.scanString(XMLUtil.java:237)\n\tat net.n3.nanoxml.StdXMLParser.processAttribute(StdXMLParser.java:485)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:382)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test10() throws Exception {
		//Parser_vw_v1_11.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_11.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 4: Expected: `='\n\tat net.n3.nanoxml.XMLUtil.errorExpectedInput(XMLUtil.java:450)\n\tat net.n3.nanoxml.StdXMLParser.processAttribute(StdXMLParser.java:482)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:382)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test11() throws Exception {
		//Parser_vw_v1_12.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_12.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO>\n    <BAR/>\n    <BAR x=\"1\"/>\n    <BAR x=\"1\" y=\"2\"/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n    <BAR>blah</BAR>\n    <BAR x=\"1\">blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

	public void test12() throws Exception {
		//Parser_vw_v1_13.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_13.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 1: Expected: `='\n\tat net.n3.nanoxml.XMLUtil.errorExpectedInput(XMLUtil.java:450)\n\tat net.n3.nanoxml.StdXMLParser.processAttribute(StdXMLParser.java:482)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:382)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test13() throws Exception {
		//Parser_vw_v1_14.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_14.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" java.io.IOException: Unexpected EOF\n\tat net.n3.nanoxml.StdXMLReader.read(StdXMLReader.java:354)\n\tat net.n3.nanoxml.XMLUtil.skipComment(XMLUtil.java:68)\n\tat net.n3.nanoxml.StdXMLParser.processSpecialTag(StdXMLParser.java:259)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:197)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test14() throws Exception {
		//Parser_vw_v1_15.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_15.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" java.io.IOException: Unexpected EOF\n\tat net.n3.nanoxml.StdXMLReader.read(StdXMLReader.java:354)\n\tat net.n3.nanoxml.XMLUtil.skipComment(XMLUtil.java:68)\n\tat net.n3.nanoxml.StdXMLParser.processSpecialTag(StdXMLParser.java:259)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:197)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test15() throws Exception {
		//Parser_vw_v1_16.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_16.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 3: Duplicate attribute: x\n\tat net.n3.nanoxml.StdXMLBuilder.addAttribute(StdXMLBuilder.java:191)\n\tat net.n3.nanoxml.StdXMLParser.processAttribute(StdXMLParser.java:487)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:382)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test16() throws Exception {
		//Parser_vw_v1_17.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_17.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO z=\"defaultValue\" y=\"fixedValue\">blah</FOO>\n");
	}

	public void test17() throws Exception {
		//Parser_vw_v1_18.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_18.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 2: Expected: `>'\n\tat net.n3.nanoxml.XMLUtil.errorExpectedInput(XMLUtil.java:450)\n\tat net.n3.nanoxml.StdXMLParser.processDocType(StdXMLParser.java:332)\n\tat net.n3.nanoxml.StdXMLParser.processSpecialTag(StdXMLParser.java:255)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:197)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test18() throws Exception {
		//Parser_vw_v1_19.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_19.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" java.io.FileNotFoundException: test.dtd (No such file or directory)\n\tat java.io.FileInputStream.open(Native Method)\n\tat java.io.FileInputStream.<init>(FileInputStream.java:106)\n\tat java.io.FileInputStream.<init>(FileInputStream.java:66)\n\tat sun.net.www.protocol.file.FileURLConnection.connect(FileURLConnection.java:70)\n\tat sun.net.www.protocol.file.FileURLConnection.getInputStream(FileURLConnection.java:161)\n\tat java.net.URL.openStream(URL.java:1007)\n\tat net.n3.nanoxml.StdXMLReader.openStream(StdXMLReader.java:463)\n\tat net.n3.nanoxml.StdXMLParser.processDocType(StdXMLParser.java:336)\n\tat net.n3.nanoxml.StdXMLParser.processSpecialTag(StdXMLParser.java:255)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:197)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test19() throws Exception {
		//Parser_vw_v1_20.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_20.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 3: Invalid entity: `&value;'\n\tat net.n3.nanoxml.XMLUtil.errorInvalidEntity(XMLUtil.java:465)\n\tat net.n3.nanoxml.XMLUtil.scanEntity(XMLUtil.java:310)\n\tat net.n3.nanoxml.XMLUtil.read(XMLUtil.java:391)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:425)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test20() throws Exception {
		//Parser_vw_v1_21.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_21.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">blah</FOO>\n");
	}

	public void test21() throws Exception {
		//Parser_vw_v1_22.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_22.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test22() throws Exception {
		//Parser_vw_v1_23.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_23.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    <BAR>vaz</BAR>\n    \nblah\n</FOO>\n");
	}

	public void test23() throws Exception {
		//Parser_vw_v1_24.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_24.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    blah\n\n    <BAR> vaz</BAR>\n</FOO>\n");
	}

	public void test24() throws Exception {
		//Parser_vw_v1_25.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_25.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test25() throws Exception {
		//Parser_vw_v1_26.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_26.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test26() throws Exception {
		//Parser_vw_v1_27.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_27.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test27() throws Exception {
		//Parser_vw_v1_28.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_28.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test28() throws Exception {
		//Parser_vw_v1_29.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_29.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test29() throws Exception {
		//Parser_vw_v1_30.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_30.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test30() throws Exception {
		//Parser_vw_v1_31.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_31.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test31() throws Exception {
		//Parser_vw_v1_32.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_32.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test32() throws Exception {
		//Parser_vw_v1_33.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_33.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test33() throws Exception {
		//Parser_vw_v1_34.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_34.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test34() throws Exception {
		//Parser_vw_v1_35.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_35.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test35() throws Exception {
		//Parser_vw_v1_36.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_36.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test36() throws Exception {
		//Parser_vw_v1_37.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_37.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test37() throws Exception {
		//Parser_vw_v1_38.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_38.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test38() throws Exception {
		//Parser_vw_v1_39.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_39.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test39() throws Exception {
		//Parser_vw_v1_40.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_40.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test40() throws Exception {
		//Parser_vw_v1_41.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_41.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test41() throws Exception {
		//Parser_vw_v1_42.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_42.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test42() throws Exception {
		//Parser_vw_v1_43.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_43.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test43() throws Exception {
		//Parser_vw_v1_44.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_44.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test44() throws Exception {
		//Parser_vw_v1_45.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_45.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test45() throws Exception {
		//Parser_vw_v1_46.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_46.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test46() throws Exception {
		//Parser_vw_v1_47.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_47.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test47() throws Exception {
		//Parser_vw_v1_48.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_48.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test48() throws Exception {
		//Parser_vw_v1_49.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_49.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test49() throws Exception {
		//Parser_vw_v1_50.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_50.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test50() throws Exception {
		//Parser_vw_v1_51.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_51.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test51() throws Exception {
		//Parser_vw_v1_52.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_52.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n    \nblah\n\n</FOO>\n");
	}

	public void test52() throws Exception {
		//Parser_vw_v1_53.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_53.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"2\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test53() throws Exception {
		//Parser_vw_v1_54.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_54.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<Foo a=\"test\" xmlns=\"http://nanoxml.n3.net/foo\">vaz\n</Foo>\n");
	}

	public void test54() throws Exception {
		//Parser_vw_v1_55.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_55.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test55() throws Exception {
		//Parser_vw_v1_56.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_56.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test56() throws Exception {
		//Parser_vw_v1_57.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_57.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test57() throws Exception {
		//Parser_vw_v1_58.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_58.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<Foo a=\"test\" xmlns=\"http://nanoxml.n3.net/foo\">\n    vaz\n\n    <Blah x=\"1\" ns:x=\"2\"/>\n</Foo>\n");
	}

	public void test58() throws Exception {
		//Parser_vw_v1_59.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_59.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test59() throws Exception {
		//Parser_vw_v1_60.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_60.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test60() throws Exception {
		//Parser_vw_v1_61.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_61.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test61() throws Exception {
		//Parser_vw_v1_62.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_62.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test62() throws Exception {
		//Parser_vw_v1_63.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_63.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"3\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test63() throws Exception {
		//Parser_vw_v1_64.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_64.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"3\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test64() throws Exception {
		//Parser_vw_v1_65.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_65.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"3\" y=\"2\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test65() throws Exception {
		//Parser_vw_v1_66.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_66.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" net.n3.nanoxml.XMLParseException: XML Not Well-Formed at Line 19: Closing tag does not match opening tag: `ns:Bar' != `Bar'\n\tat net.n3.nanoxml.XMLUtil.errorWrongClosingTag(XMLUtil.java:497)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:436)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.processElement(StdXMLParser.java:451)\n\tat net.n3.nanoxml.StdXMLParser.scanSomeTag(StdXMLParser.java:202)\n\tat net.n3.nanoxml.StdXMLParser.scanData(StdXMLParser.java:159)\n\tat net.n3.nanoxml.StdXMLParser.parse(StdXMLParser.java:133)\n\tat Parser1_vw_v1.main(Parser1_vw_v1.java:51)\n");
	}

	public void test66() throws Exception {
		//Parser_vw_v1_67.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_67.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"3\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test67() throws Exception {
		//Parser_vw_v1_68.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_68.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"3\" y=\"2\">\n    test\n\n    <BAR>vaz</BAR>\n</FOO>\n");
	}

	public void test68() throws Exception {
		//Parser_vw_v1_69.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_69.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"3\" y=\"2\">\n    test\n\n    <VAZ>vaz</VAZ>\n    INCLUDE\n\n</FOO>\n");
	}

	public void test69() throws Exception {
		//Parser_vw_v1_70.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_70.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<Foo a=\"test\" xmlns=\"http://nanoxml.n3.net/foo\">vaz\n</Foo>\n");
	}

	public void test70() throws Exception {
		//Parser_vw_v1_71.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_71.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">test\n</FOO>\n");
	}

	public void test71() throws Exception {
		//Parser_vw_v1_72.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_72.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">test\n</FOO>\n");
	}

	public void test72() throws Exception {
		//Parser_vw_v1_73.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_73.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">INCLUDE\n</FOO>\n");
	}

	public void test73() throws Exception {
		//Parser_vw_v1_74.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_74.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<Foo a=\"test\" xmlns=\"http://nanoxml.n3.net/foo\">vaz\n</Foo>\n");
	}

	public void test74() throws Exception {
		//Parser_vw_v1_75.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_75.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">test\n</FOO>\n");
	}

	public void test75() throws Exception {
		//Parser_vw_v1_76.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_76.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">test\n</FOO>\n");
	}

	public void test76() throws Exception {
		//Parser_vw_v1_77.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_77.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" z=\"defaultValue\" y=\"fixedValue\">INCLUDE\n</FOO>\n");
	}

	public void test77() throws Exception {
		//Parser_vw_v1_78.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_78.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<Foo b=\"test1\" a=\"test\" d=\"test4\" xmlns=\"http://nanoxml.n3.net/foo\" c=\"test3\">vaz\n</Foo>\n");
	}

	public void test78() throws Exception {
		//Parser_vw_v1_79.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_79.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" a=\"5\" z=\"3\" y=\"2\">test\n</FOO>\n");
	}

	public void test79() throws Exception {
		//Parser_vw_v1_80.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_80.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" a=\"5\" z=\"3\" y=\"2\">test\n</FOO>\n");
	}

	public void test80() throws Exception {
		//Parser_vw_v1_81.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_81.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" a=\"7\" z=\"3\" y=\"2\">INCLUDE\n</FOO>\n");
	}

	public void test81() throws Exception {
		//Parser_vw_v1_82.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_82.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<Foo b=\"test1\" a=\"test\" d=\"test4\" xmlns=\"http://nanoxml.n3.net/foo\" c=\"test3\">vaz\n</Foo>\n");
	}

	public void test82() throws Exception {
		//Parser_vw_v1_83.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_83.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" a=\"5\" z=\"3\" y=\"2\">test\n</FOO>\n");
	}

	public void test83() throws Exception {
		//Parser_vw_v1_84.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_84.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" a=\"5\" z=\"3\" y=\"2\">test\n</FOO>\n");
	}

	public void test84() throws Exception {
		//Parser_vw_v1_85.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/testvw_85.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO x=\"1\" a=\"7\" z=\"3\" y=\"2\">INCLUDE\n</FOO>\n");
	}

	public void test85() throws Exception {
		//Parser_vw_v1_87.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Parser1_vw_v1.main(new String[] {"/home/dallmeier/inputs/simple.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO>\n    <BAR/>\n    <BAR x=\"1\"/>\n    <BAR x=\"1\" y=\"2\"/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n    <BAR>blah</BAR>\n    <BAR x=\"1\">blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

}
