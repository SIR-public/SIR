package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoRemoveAttr2_wy_v1Tests extends TestCase {

	public void test0() throws Exception {
		//rmattr2.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RemoveAttr2_wy_v1.main(new String[] {"/home/dallmeier/inputs/file1_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO age=\"20\" unit=\"LB\" weight=\"80\">\n    <BAR1/>\n    <BAR2 x=\"1\"/>\n    <BAR3 x=\"1\" y=\"2\"/>\n    <BAR4>\n        <BAR5/>\n        <BARBAR1/>\n        <BA1/>\n        <FOO1/>\n    </BAR4>\n    <BAR6>blah</BAR6>\n    <BAR7 x=\"1\">blah</BAR7>\n    <BAR8>&lt;&amp;&gt;&apos;&quot;</BAR8>\n    <BAR9>abc</BAR9>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

	public void test1() throws Exception {
		//rmattr3.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RemoveAttr2_wy_v1.main(new String[] {"/home/dallmeier/inputs/emptyelem3_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<Flower smell=\"Sweet\" color=\"Red\" name=\"Rose\" season=\"Spring\"/>\n");
	}

	public void test2() throws Exception {
		//rmattr4.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RemoveAttr2_wy_v1.main(new String[] {"/home/dallmeier/inputs/simple.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO>\n    <BAR/>\n    <BAR x=\"1\"/>\n    <BAR x=\"1\" y=\"2\"/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n    <BAR>blah</BAR>\n    <BAR x=\"1\">blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

}
