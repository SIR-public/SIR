package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoRemoveChildIndex3_wy_v1Tests extends TestCase {

	public void test0() throws Exception {
		//rmchildindx3.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RemoveChildIndex3_wy_v1.main(new String[] {"/home/dallmeier/inputs/file4_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" java.lang.ArrayIndexOutOfBoundsException: 0 >= 0\n\tat java.util.Vector.removeElementAt(Vector.java:518)\n\tat net.n3.nanoxml.XMLElement.removeChildAtIndex(XMLElement.java:204)\n\tat RemoveChildIndex3_wy_v1.main(RemoveChildIndex3_wy_v1.java:48)\n");
	}

	public void test1() throws Exception {
		//rmchildindx4.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RemoveChildIndex3_wy_v1.main(new String[] {"/home/dallmeier/inputs/simple.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "<FOO>\n    <BAR x=\"1\"/>\n    <BAR x=\"1\" y=\"2\"/>\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n    <BAR>blah</BAR>\n    <BAR x=\"1\">blah</BAR>\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n    <BAR>abc</BAR>\n    \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n</FOO>\n");
	}

}
