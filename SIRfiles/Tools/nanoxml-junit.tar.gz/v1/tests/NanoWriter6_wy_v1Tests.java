package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoWriter6_wy_v1Tests extends TestCase {

	public void test0() throws Exception {
		//writer6.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/emptyelem3_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <Flower smell=\"Sweet\" color=\"Red\" name=\"Rose\" season=\"Spring\"/>\n");
	}

	public void test1() throws Exception {
		//writer7.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/file4_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO unit=\"LB\"/>\n");
	}

	public void test2() throws Exception {
		//writer8.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/file10_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO>\n      <BAR/>\n      <BAR x=\"1\"/>\n      <BAR x=\"1\" y=\"2\"/>\n      <BAR>\n          <BAR/>\n          <BARBAR/>\n          <BA/>\n          <FOO/>\n      </BAR>\n      <BAR>blah</BAR>\n      <BAR x=\"1\">blah</BAR>\n      <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n      <BAR>abc</BAR>\n  </FOO>\n");
	}

	public void test3() throws Exception {
		//writer9.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/file11_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO>\n   This element does not have children.\n   It just contain PCDATA.&#x9;\n</FOO>\n");
	}

	public void test4() throws Exception {
		//writer10.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/simple.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO>\n      <BAR/>\n      <BAR x=\"1\"/>\n      <BAR x=\"1\" y=\"2\"/>\n      <BAR>\n          <BAR/>\n          <BARBAR/>\n          <BA/>\n          <FOO/>\n      </BAR>\n      <BAR>blah</BAR>\n      <BAR x=\"1\">blah</BAR>\n      <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n      <BAR>abc</BAR>\n      \n&#x9;&lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n  </FOO>\n");
	}

	public void test5() throws Exception {
		//writer11.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/file12_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO age=\"20\" unit=\"LB\" weight=\"80\" direction=\"north\"/>\n");
	}

	public void test6() throws Exception {
		//writer12.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/file7_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO age=\"20\" unit=\"LB\" weight=\"80\" direction=\"north\">\n      <BAR1/>\n      <BAR2 x=\"1\"/>\n      <BAR3 x=\"1\" y=\"2\"/>\n      <BAR4>\n          <BAR5/>\n          <BARBAR1/>\n          <BA1/>\n          <FOO1/>\n      </BAR4>\n      <BAR6>blah</BAR6>\n      <BAR7 x=\"1\">blah</BAR7>\n      <BAR8>&lt;&amp;&gt;&apos;&quot;</BAR8>\n      <BAR9>abc</BAR9>\n  </FOO>\n");
	}

	public void test7() throws Exception {
		//writer13.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/file8_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO unit=\"LB\">\n   This element does not have children.\n   It just contain PCDATA.&#x9;\n</FOO>\n");
	}

	public void test8() throws Exception {
		//writer14.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		Writer6_wy_v1.main(new String[] {"/home/dallmeier/inputs/file9_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "  <FOO age=\"20\" unit=\"LB\" weight=\"80\" direction=\"north\">\n      <BAR1/>\n      <BAR2 x=\"1\"/>\n      <BAR3 x=\"1\" y=\"2\"/>\n      \n&#x9;This elem contain some data with posi higher than BAR6.\n&#x9;\n      <BAR4>\n          <BAR5/>\n          <BARBAR1/>\n          <BA1/>\n          <FOO1/>\n      </BAR4>\n      <BAR6>blah</BAR6>\n      <BAR7 x=\"1\">blah</BAR7>\n      <BAR8>&lt;&amp;&gt;&apos;&quot;</BAR8>\n      <BAR9>abc</BAR9>\n  </FOO>\n");
	}

}
