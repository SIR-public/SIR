package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoREnumChildren_wy_v2Tests extends TestCase {

	public void test0() throws Exception {
		//renumchild1.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		REnumChildren_wy_v2.main(new String[] {"/home/dallmeier/inputs/emptyelem2_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements are: \n\n");
	}

	public void test1() throws Exception {
		//renumchild2.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		REnumChildren_wy_v2.main(new String[] {"/home/dallmeier/inputs/file3_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements are: \n\n");
	}

	public void test2() throws Exception {
		//renumchild3.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		REnumChildren_wy_v2.main(new String[] {"/home/dallmeier/inputs/file4_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements are: \n\n");
	}

	public void test3() throws Exception {
		//renumchild4.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		REnumChildren_wy_v2.main(new String[] {"/home/dallmeier/inputs/file5_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements are: \n    <BAR9>abc</BAR9>\n\n    &lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n\n");
	}

	public void test4() throws Exception {
		//renumchild5.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		REnumChildren_wy_v2.main(new String[] {"/home/dallmeier/inputs/file6_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements are: \n    <BAR9>abc</BAR9>\n\n\n");
	}

	public void test5() throws Exception {
		//renumchild6.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		REnumChildren_wy_v2.main(new String[] {"/home/dallmeier/inputs/file1_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements are: \n    <BAR1/>\n\n    <BAR2 x=\"1\"/>\n\n    <BAR3 x=\"1\" y=\"2\"/>\n\n    <BAR4>\n        <BAR5/>\n        <BARBAR1/>\n        <BA1/>\n        <FOO1/>\n    </BAR4>\n\n    <BAR6>blah</BAR6>\n\n    <BAR7 x=\"1\">blah</BAR7>\n\n    <BAR8>&lt;&amp;&gt;&apos;&quot;</BAR8>\n\n    <BAR9>abc</BAR9>\n\n    &lt;&amp;&gt;&quot;&apos;!:&#x2030;\n\n\n");
	}

	public void test6() throws Exception {
		//renumchild7.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		REnumChildren_wy_v2.main(new String[] {"/home/dallmeier/inputs/file7_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements are: \n    <BAR1/>\n\n    <BAR2 x=\"1\"/>\n\n    <BAR3 x=\"1\" y=\"2\"/>\n\n    <BAR4>\n        <BAR5/>\n        <BARBAR1/>\n        <BA1/>\n        <FOO1/>\n    </BAR4>\n\n    <BAR6>blah</BAR6>\n\n    <BAR7 x=\"1\">blah</BAR7>\n\n    <BAR8>&lt;&amp;&gt;&apos;&quot;</BAR8>\n\n    <BAR9>abc</BAR9>\n\n\n");
	}

}
