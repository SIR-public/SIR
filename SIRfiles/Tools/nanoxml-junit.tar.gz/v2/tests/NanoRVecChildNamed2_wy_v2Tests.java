package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoRVecChildNamed2_wy_v2Tests extends TestCase {

	public void test0() throws Exception {
		//rvecchildnamed2.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RVecChildNamed2_wy_v2.main(new String[] {"/home/dallmeier/inputs/file1_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "Exception in thread \"main\" java.lang.NullPointerException\n\tat net.n3.nanoxml.XMLElement.getChildrenNamed(XMLElement.java:340)\n\tat RVecChildNamed2_wy_v2.main(RVecChildNamed2_wy_v2.java:48)\n");
	}

	public void test1() throws Exception {
		//rvecchildnamed3.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RVecChildNamed2_wy_v2.main(new String[] {"/home/dallmeier/inputs/file7_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements with the name BAR6 are: \n    <BAR6>blah</BAR6>\n\n");
	}

}
