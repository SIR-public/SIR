package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoCheckLeaf2_wy_v3Tests extends TestCase {

	public void test0() throws Exception {
		//checkleaf2.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		CheckLeaf2_wy_v3.main(new String[] {"/home/dallmeier/inputs/file1_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "The child element named BAR7 is a leaf element.\n");
	}

}
