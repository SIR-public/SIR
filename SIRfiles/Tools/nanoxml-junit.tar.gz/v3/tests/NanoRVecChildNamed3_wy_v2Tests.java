package tests;

import junit.framework.TestCase;
import java.io.ByteArrayOutputStream;
import java.io.PrintStream;
import net.n3.nanoxml.*;

public class NanoRVecChildNamed3_wy_v2Tests extends TestCase {

	public void test0() throws Exception {
		//rvecchildnamed4.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RVecChildNamed3_wy_v2.main(new String[] {"/home/dallmeier/inputs/simple.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements with the name BAR are: \n    <BAR/>\n\n    <BAR x=\"1\"/>\n\n    <BAR x=\"1\" y=\"2\"/>\n\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n\n    <BAR>blah</BAR>\n\n    <BAR x=\"1\">blah</BAR>\n\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n\n    <BAR>abc</BAR>\n\n");
	}

	public void test1() throws Exception {
		//rvecchildnamed5.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RVecChildNamed3_wy_v2.main(new String[] {"/home/dallmeier/inputs/file10_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements with the name BAR are: \n    <BAR/>\n\n    <BAR x=\"1\"/>\n\n    <BAR x=\"1\" y=\"2\"/>\n\n    <BAR>\n        <BAR/>\n        <BARBAR/>\n        <BA/>\n        <FOO/>\n    </BAR>\n\n    <BAR>blah</BAR>\n\n    <BAR x=\"1\">blah</BAR>\n\n    <BAR>&lt;&amp;&gt;&apos;&quot;</BAR>\n\n    <BAR>abc</BAR>\n\n");
	}

	public void test2() throws Exception {
		//rvecchildnamed6.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RVecChildNamed3_wy_v2.main(new String[] {"/home/dallmeier/inputs/file1_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements with the name BAR are: \n");
	}

	public void test3() throws Exception {
		//rvecchildnamed7.out
		String result;
		ByteArrayOutputStream byteBuffer;

		byteBuffer = new ByteArrayOutputStream();
		System.setOut(new PrintStream(byteBuffer));
		RVecChildNamed3_wy_v2.main(new String[] {"/home/dallmeier/inputs/file7_wy.xml"});
		result = new String(byteBuffer.toByteArray());
		assertEquals(result, "All child elements with the name BAR are: \n");
	}

}
