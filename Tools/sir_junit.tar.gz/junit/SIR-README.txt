SIR JUnit Non-Determinism Modificatons

The jars 