#include <stdio.h>
#include <stdlib.h>
#include <sys/time.h>

int main()
{
 struct timeval tp;

 gettimeofday(&tp, NULL);

 printf("%lf\n", tp.tv_sec + (double) tp.tv_usec / 1000000.0);

 return 0;
}

