#!/usr/local/bin/perl
#
# Program to do the obvious
#
if ($#ARGV != 1) {
    print "usage: time.pl Input_Filename Output_Filename \n";
    exit;
}

$file1 = $ARGV[0];
$file2 = $ARGV[1];
open(INFO1,$file1);
open(INFO2,">$file2");
$b=0;
while($line = <INFO1>)
{
 if($line =~ /S.*=.*/)
 {
 	chop $line;
 	($var,$val_1) = split("=",$line);
 }
 if($line =~ /F.*=.*/)
 {
 	chop $line;
 	($var,$val_2) = split("=",$line);
 	$time = $val_2 - $val_1 ;
        print  INFO2 "unitest$b: $time \n";
        $b++;
        
 }
}
close(INFO1);
close(INFO2);
open(INFO2,$file2);
@lines = <INFO2>;
close(INFO2);
$num_test = $b;
open(INFO2,">$file2");
print INFO2 "number of tests = $num_test\n";
print INFO2 @lines;
close(INFO2);

