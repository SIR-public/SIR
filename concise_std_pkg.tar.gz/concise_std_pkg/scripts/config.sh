# configuration settings for web & database
# of yourcontacts subject
#
# URL base address of installed subject for tests, HTTP port
# can be inserted here: e.g. http://localhost:8080/~user
URLBASE=http://localhost/~user
#
# hosting directory to install the subject into for Apache web server
# to present it from, e.g. ~/public_html or /var/apache/htdocs etc.
LOCALWEBDIR=/home/user/public_html
#
# name of the Apache server hosting this, typically localhost
HOST=localhost
#
# name of database user ID for database transactions, set this to the name
# of the MySQL/MariaDB user, similarly for other DB platforms but
# these would also require changes to dolifunctions.sh, see README
DBUSER=dbuser
#
# password of the database user ID DBUSER
DBUSERPW=dbpassword
#
# Change this if you have a non-MySQL server backend for yourcontacts
# other types supported by yourcontacts: pgsql (postgre) and mssql (MS SQL)
# If an alternate is chosen, you will need to modify the dolifunctions.sh
# initTables function script to utilize these non-mysql table and data init
# files as input for these, since yourcontacts installer uses the driver to
# convert the MySQL files to the format used by these other DBMS types
# as well as generate your own dbinit.sql equivalent file in the versions
# directory.
# This MUST be set to mysql to get the DB to work right with PHP versions
# beyond PHP 5.3, using mysqli will cause a fatal PHP error because
# the mysqli code uses the deprecated mysqli_client_encoding() function
DBTYPE=mysql
#
# Change this if your installation uses a non-std MySQL TCP port #
DBPORT=3306
#
# app web administrator login id, unsupported for yourcontacts
#APPADMIN=admin
#
# app web administrator login password, unsupported for yourcontacts
#APPADMPW=admin
#
# prefixing flag, if set to 1 indicates a
# prefix should be applied to the table names
# for unique table identifiers when same
# database is used for all versions
# NOTE: this is not applicable to versions prior to v6
# since v1-5 do not pervasively use table prefixing
PREFIXDBTABLES=0
#
# yourcontacts default prefix is 'llx_' change if you want unique tablenames
# empty denotes use default in yourcontacts installer scripts
# Note: this is only applicable/honored in SIR versions v6-v30
DBPREFIX=""
#
# set CREATEDBUSER=1 if you want the database user created
# requires DBROOTUSER and DBROOTPW to be valid, see below
CREATEDBUSER=0
#
# set GRANTDBPERMS=1 if you want the script to grant permissions
# on the SQL DB, ${sqldb} for the SQL user $sqlid (see install.sh) 
# requires DBROOTUSER and DBROOTPW to be valid, see below
GRANTPERMS=0
#
# Set CREATEDB=1 if you want install.sh script to create the mysql database
# this requires setting the DBROOTUSER and DBROOTPW to be valid for the
# mysql server root login and password (can be a user granted DB CREATE
# and GRANT permissions in MySQL server)
CREATEDB=0
#
# Set CLEARDB=1 if you want to remove the contents of the mysql database
# for the version being installed.  Requires ROOTDBUSER/ROOTDBPW to be valid
CLEARDB=0
# DB root user/user having been granted DB create/grant permissions
DBROOTUSER=root
# DB root password/user password with DB create/grant perms
DBROOTPW=root
