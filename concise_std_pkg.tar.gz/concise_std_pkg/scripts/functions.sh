# functions.sh contains functions to:
# getFileType:    get the type of the file from the filename extension
#                 returns 0 to 3 depending on filetype identified
# dwnldObject:    download a subject from a web repository via URL
# dwnldGitObject: download a subject from a git repository
#                 and configure it for a specific commit id
# saveObject:     saves a copy of the subject in source directory
#                 to the originals directory
# createDB:       creates the database on the host MySQL server
# createUser:     creates the user on the host MySQL server
# grantDB:        grants permissions on the database to the MySQL user
# getFileType:    intended to get the filetype requested in a URL/string
# copyObject:     copies an object from the versions directory copy
#                 when the object resides within the subject (non-web)
# getHost:        detects the host type of the system running the scripts
#                 useful when scripts need to be host-type sensitive
#
# Author: Wayne Motycka
# Date: May 2018

#
# use this to determine downloaded filetype
# usage getFileType URL
#
# return:
# 0 if unknown/invalid
# 1 if zip file/link
# 2 if tar.gz file/link
# 3 if a git file/link
function getFileType {
    if [ -z "${1}" ]
    then
        return 0
    else
        if [[ ${1} =~ (\.zip)$ ]]
        then
            return 1
        elif [[ ${1} =~ (\.tar.gz)$ || ${1} =~ (\.tgz)$ ]]
        then
            return 2
        elif [[ ${1} =~ (\.git)$ ]]
        then
            return 3
        fi
    fi
    return 0
}
# dwnldObject - This function uses the curl(1) Linux shell
# command to retrieve the test subject from the specified
# (function argument) URL location.
# usage:
# dwnldObject URL [subject-name]
#
# where URL is of the form: http(s)://site.server.extension/path-to-subject
#
# subject-name is optional, and will use the relative path
# ../source which assumes that this function is executed from
# within the scripts directory of this subject.
# if subject-name is specified, $experiment_root must be set
# in calling script/environment
#
# if subject-name is specified it will be used to form the
# base path to put the subject into using the $experiment_root
# shell variable as the base.  See the SIR users manual for
# instructions on setting this shell variable
# return 0 on success, non-zero on error/failure
#
function dwnldObject {
    # Need experiment_root set in shell prior to running
    # $1 contains the URL to download from
    if [ -z ${1} ]
    then
        echo "missing URL arg to dwnldObject"
        return 1
    fi
    # determine file type of downloaded object
    getFileType ${1}
    ftype=$?
    echo "Download URL: $1"
    # create cmd line to exec curl on dest & trap http_code returned
    # for caller
    if [ -z "$2" ] # uses relative path if no subject-name not specified
    then
        case $ftype in
        1)
            cmdline="curl -so ../source/dload.zip -w %{http_code} ${1}"
            ;;
        2)
            cmdline="curl -so ../source/dload.tar.gz -w %{http_code} ${1}"
            ;;
        *)
            echo "SEVERE: dwlnObject: unknown filetype in URL; ${1}"
            ret=404  # return 404 file-not-found error
            return
            ;;
        esac
    else # uses subject-name in $2 as basedir under $experiment_root
        case $ftype in
        1)
            cmdline="curl -so ${experiment_root}/${2}/source/dload.zip -w %{http_code} ${1}"
            ;;
        2)
            cmdline="curl -so ${experiment_root}/${2}/source/dload.tar.gz -w %{http_code} ${1}"
            ;;
        *)
            echo "SEVERE: dwlnObject: unknown filetype in URL; ${1}"
            ret=404  # return 404 file-not-found error
            return
            ;;
        esac
    fi
    echo $cmdline
    # ret is evaluated by the calling function/main to determine
    # success of the download
    ret=`$cmdline`
}

# function to download an object from a git repository
# usage: dwnldGitObject git-URL commit-id
#
# where git-URL is of the form: https://github.com/user/subject.git
# commit-id is a typical git hash number, e.g.
# 5f197cb1bbc7af4ec6cca350344e90dcc5590347
# This function requires the subjectname variable to be set
# by the calling function.  It uses relative paths & expects
# the SIR packaging source tree to be used
#
function dwnldGitObject {
    if [ -z $1 ]
    then
        echo "missing git repo link"
        return 1
    fi
    if [ -z $2 ]
    then
        echo "missing git commit number"
        return 1
    fi
    if [ -z ${subjectname} ]
    then
        echo "subjectname unset in calling script"
        return 1
    fi

    echo "downloading from $1 commit id $2"
    cd ../source
    # clone subject only if needed
    if [ ! -d ./${subjectname}/.git ]
    then
        git clone $1
        if [ $? -gt 0 ]
        then
            echo "git clone failed for URL $1"
            return 1
        fi
    fi
    # 
    cd ${subjectname}
    git checkout ${2}
    if [ $? -gt 0 ]
    then
        git fetch # retry with reset
        git reset --hard origin/master
        git checkout ${2}
        if [ $? -ne 0 ]
        then
          echo "setting ${subjectname} to commit ${2} failed"
          return 1
        fi
    fi
    cd ../../scripts
}

#
# copyObject function - copies version specified to source dir
# usage
# copyObject version-number
#
# version-number, e.g. 1-N matching v1-vN format of versions dir
#
# This function is used if the subject sources are local/within the
# versions directory and is not used if dwnldObject or dwnldGitObject
# are used.
# $experiment_root and $subjectname must be set in environment/calling
# optionally set $sirsubject if the SIR subject/directory name differs
# from the $subjectname.
# Uses relative paths so expects to be in SIR package directory tree
# script -wdm
function copyObject {
    # $experiment_root & $subjectname should be set in shell/script prior
    if [ -z "${experiment_root}" -o -z "${subjectname}" ]
    then
        echo "SEVERE: copyObject: \$experiment_root or \$subjectname unset in calling script"
        return 1
    fi
    # handle case where SIR name differs from subjectname
    if [ -n "${sirsubject}" -a "${sirsubject}" != ${subjectname} ]
    then
        src="${experiment_root}/${sirsubject}/versions"
        dest="${experiment_root}/${sirsubject}/source"
    else
        src="${experiment_root}/${subjectname}/versions"
        dest="${experiment_root}/${subjectname}/source"
    fi
    if [ -z ${1} ]
    then
        echo "missing version arg to copyObject"
        return 1
    fi
    if [ -f ${src}/v${1}/*.zip ]
    then
        if [ -d ${dest}/${subjectname} ] # sbj copy already in source dir
        then
            rm -rf ${dest}/${subjectname}
        fi
        zipname=`basename ${src}/v${1}/*.zip`
        cp ${src}/v${1}/${zipname} ${dest}
        #echo "subject zipfile: $zipname"
        cd ${dest}
        # unzip with overwrite-all
        unzip -qo ${zipname}
        if [ $? -ne 0 ]
        then
            echo "ERROR: copyObject: unzip failed for ${zipname}"
            return 1
        fi
    elif [ -f ${src}/v${1}/*.tar.gz ]
    then
        if [ -d ${dest}/${subjectname} ] # sbj copy already in source dir
        then
            rm -rf ${dest}/${subjectname}
        fi
        zipname=`basename ${src}/v${1}/*.tar.gz`
        cp ${src}/v${1}/${zipname} ${dest}
        #echo "subject zipfile: $zipname"
        cd ${dest}
        tar --gunzip -xf ${zipname}
        if [ $? -ne 0 ]
        then
            echo "ERROR: copyObject: un-tar-gz failed for ${zipname}"
            return 1
        fi
    else
        echo "SEVERE: copyObject: no zip file found in ${src}/v${1} directory"
        return 1
    fi
    # rename zip-contained directories with versions #'s appended
    # to just the subjectname
    if [ -d ${subjectname}_${ver} -o -d ${subjectname}_v${ver} ]
    then
        echo "copyObject: renaming source version ${ver} to ${subjectname}"
        mv ${subjectname}_*${ver} ${subjectname}
    fi
    rm ${zipname}
    cd ../scripts # RELATIVE PATH USED HERE
    return 0
}

#
# Save a copy of the object.  This function saves the object
# in the source directory into the originals directory.  It is
# useful when you need to reinstall a subject that has been
# downloaded using the dwnldObject function.
# usage
# copyObject version-number
#
# version-number 1 to N (N=max versions)
# Returns non-zero on error
# To fully use the ability of this a modification is needed to
# dwnldObject to detect if an extant version exists in the originals
# directory prior to downloading it.  The function is offered here for
# a future user to implement the modification.
function saveObject {
    if [ -z "${experiment_root}" -o -z "${subjectname}" ]
    then
        echo "SEVERE: saveObject: \$experiment_root or \$subjectname unset in calling script"
        return 1
    fi
    if [ -n "${sirsubject}" -a "${sirsubject}" != ${subjectname} ]
    then
        src="${experiment_root}/${sirsubject}/source"
        dest="${experiment_root}/${sirsubject}/originals"
    else
        src="${experiment_root}/${subjectname}/source"
        dest="${experiment_root}/${subjectname}/originals"
    fi
    if [ -z "$1" ]
    then
        echo "missing version arg to saveObject"
        return 1
    fi
    if [ -d ${source}/${subjectname} ]
    then
        if [ -d ${dest}/v${ver} ]
        then
            if [ -d ${dest}/v${ver}/${subjectname} ]
            then
                rm -rf ${dest}/v${ver}/${subjectname}
            fi
            cp -r ${source}/${subjectname} ${dest}/v${ver}
        else
            mkdir ${dest}/v${ver}
            cp -r ${source}/${subjectname} ${dest}/v${ver}
        fi
    fi
}

#
# create the SQL database user if desired, requires DBROOTUSER and DBROOTPW
# DBTYPE, sqlid, sqlpw, and CREATEDBUSER shell variables set
# see config.sh and install.sh for details on these variables
# This function is designed for use on a MySQL/MariaDB system and
# will need changes to work on any other DBMS
# returns 0 if successful, 1 on failure
function createUser {
    if [ -z "${sqlid}" -o -z "${sqlpw}" -o -z "${DBTYPE}" -o -z "${DBPORT}" -o -z "${svrname}" ]
    then
        echo "SEVERE: createUser: \$sqlid, \$sqlpw, \$svrname, \$DBPORT or \$DBTYPE unset in calling script"
        return 1
    fi
    if [ -n "${CREATEDBUSER}" ]
    then
        if [ ${CREATEDBUSER} = "1" ]
        then
            if [ -n "${DBROOTUSER}" -a -n "${DBROOTPW}" ]
            then
                if [[ ${DBTYPE} =~ "mysql" ]]
                then
                    echo "SELECT user FROM mysql.user WHERE user='${sqlid}' LIMIT 1;" > tmp.sql
                    qret=`mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < tmp.sql 2>errfile | grep ${sqlid}`
                    if [ $? -ne 0 ]
                    then
                        echo "SEVERE: createUser: DBROOTUSER/DBROOTPW invalid?"
                        cat errfile
                        rm -rf tmp.sql errfile
                        return 1
                    fi
                    rm -rf errfile
                    if [[ ! $qret =~ $sqlid ]]
                    then   
                        echo "CREATE USER '${sqlid}'@'%' IDENTIFIED BY '${sqlpw}';" > newuser.sql
                        # may want a localhost user instead, % is all hosts
                        #echo "CREATE USER '${sqlid}'@'localhost' IDENTIFIED BY '${sqlpw}';" >> newuser.sql
                        #echo "GRANT ALL PRIVILEGES ON ${sqldb}.* to '${sqlid}'@'localhost';" >> newuser
                        echo "GRANT ALL PRIVILEGES ON ${sqldb}.* to '${sqlid}'@'%';" >> newuser
                        mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < newuser.sql 2>errfile
                        if [ $? -gt 0 ]
                        then
                            echo "SEVERE: createUser: mysql user create failed"
                            cat errfile
                            rm -rf tmp.sql newuser.sql errfile
                            return 1
                        fi
                    else
                        echo "$sqlid already exists, use grantDB if privileges required on database"
                        rm -rf tmp.sql errfile
                    fi
                else # Add elif for non-MySQL DB hosts here
                    echo "non-MySQL DB specified, cannot create user, unimplemented"
                    return 1
                fi
            else
                echo "SEVERE: createUser: DBROOTUSER or DBROOTPW unset, cannot create user"
                return 1
            fi
        fi
    fi
    rm -rf tmp.sql newuser.sql errfile
}

#
# createDB creates the ${sqldb} database within the MySQL server
# requires DBROOTUSER and DBROOTPW to be set in calling script
function createDB {
    if [ -n "${DBROOTUSER}" -a -n "${DBROOTPW}" -a -n "${DBPORT}" -a -n "${sqldb}" -a -n "${svrname}" ]
    then
        echo "SELECT SCHEMA_NAME FROM INFORMATION_SCHEMA.SCHEMATA WHERE SCHEMA_NAME='${sqldb}' LIMIT 1;" > chkdb.sql
        mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < chkdb.sql 2>errfile > sql.out
        if [ $? -ne 0 ] # returns non-zero when DB doesn't exist, 0 if it does
        then
            echo "ERROR: createDB: query failed for existing ${sqldb} DB, invalid \$DBROOTUSR or \$DBROOTPW ?"
            cat errfile
            rm chkdb.sql errfile sql.out
            return 1
        fi
        ckret=`grep ${sqldb} sql.out`
        if [[ ! $ckret =~ ${sqldb} ]]
        then
            echo "CREATE DATABASE IF NOT EXISTS ${sqldb} COLLATE='utf8_unicode_ci';" > newdb.sql
            #echo "CREATE DATABASE IF NOT EXISTS ${sqldb};" > newdb.sql
            #echo "mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < newdb.sql"
            mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < newdb.sql 2>errfile
            if [ $? -gt 0 ]
            then
                echo "SEVERE: createDB: database creation failed, mysql error:"
                cat errfile
                rm newdb.sql errfile
                return 1
            fi
            rm newdb.sql errfile
        else
            echo "database ${sqldb} already exists"
            if [ -n "${CLEARDB}" -a "${CLEARDB}" = "1" ]
            then
                echo "CLEARDB is set, database will be initialized empty"
                echo "DROP DATABASE ${sqldb};" > rmdb.sql
                #echo "CREATE DATABASE IF NOT EXISTS ${sqldb};" >> rmdb.sql
                echo "CREATE DATABASE IF NOT EXISTS ${sqldb} COLLATE='utf8_unicode_ci';" >> rmdb.sql
                mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < rmdb.sql 2>errfile
                if [ $? -gt 0 ]
                then
                    echo "SEVERE: createDB: database re-initialization failed, mysql returned non-zero"
                    cat errfile
                    rm rmdb.sql errfile
                    return 1
                fi
                rm rmdb.sql errfile
            else
                echo "database will be left in current state"
            fi
        fi
    else
        echo "SEVERE: createDB: DBROOTUSER, DBROOTPW, svrname, sqldb or sqlid unset in calling script"
        return 1
    fi
    rm -rf newdb.sql chkdb.sql rmdb.sql errfile
}

#
# grant permissions to $sqlid user for database $sqldb
# requires DBROOTUSER and DBROOTPW to be set
function grantDB {
    if [ -n "${DBROOTUSER}" -a -n "${DBROOTPW}" ]
    then
        if [ -n "${sqlid}" -a -n "${sqldb}" -a -n "${svrname}" -a -n "${DBPORT}" ]
        then
            echo "GRANT ALL PRIVILEGES ON ${sqldb}.* TO '${sqlid}'@'%';" > newuser.sql
            # grant for localhost user if desired
            #echo "GRANT ALL PRIVILEGES ON ${sqldb}.* TO '${sqlid}'@'%';" >> newuser.sql
            echo "FLUSH PRIVILEGES;" >> newuser.sql
            #echo "mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < newuser.sql"
            mysql -h ${svrname} -P ${DBPORT} -u ${DBROOTUSER} --password=${DBROOTPW} < newuser.sql 2>errfile
            if [ $? -gt 0 ]
            then
                echo "SEVERE: grantDB: mysql user create failed"
                cat errfile
                rm -rf newuser.sql errfile
                return 1
            fi
        else
            echo "SEVERE: grantDB: \$sqlid, \$sqldb, \$DBPORT, or \$svrname unset by calling script"
            return 1
        fi
    else
        echo "NOTICE: grantDB: \$DBROOTUSER or \$DBROOTPW unset in calling script"
    fi
    rm -rf newuser.sql errfile
}

# Get the host system type, return as an integer
# sets shelltype global variable to one of:
# 0 unknown
# 1 Linux
# 2 Windows
# 3 Mac OS
function getHost {
    info=`uname -s`
    if [ ${info} = "Darwin" ]
    then
        shelltype=3;
    elif [ `expr substr ${info} 1 5` = "Linux" ]
    then
        shelltype=1;
    elif [ `expr substr ${info} 1 10` = "MINGW32_NT" ]
    then
        shelltype=2;
    elif [ `expr substr ${info} 1 10` = "MINGW64_NT" ]
    then
        shelltype=2;
    elif [ `expr substr ${info} 1 9` = "CYGWIN_NT" ]
    then
        shelltype=2;
    else
        shelltype=0;
    fi
}
