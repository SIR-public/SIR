<?php
// returns the current date in the form Joomla uses for users table
  $value=date("Y-m-d h:i:s");
  print $value;
?>
