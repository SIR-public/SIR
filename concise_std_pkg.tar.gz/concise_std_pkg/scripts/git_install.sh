#!/bin/bash
#
# This is an install script that reflects using the Git
# concise object scripts.  This script is compatible
# with the giturl and gitcommit provided in the versions
# directory of this sample package, although it does
# not do the SQL database provisioning done by the dolibarr
# subject.
#
# Include the functions.sh file to make these functions
# available for use in the install.sh script
source functions.sh
# Include the config.sh file so the values set in it are
# available to this script and others
source config.sh

# Include any Bash functions that are custom to your
# installation
#source custom_functions.sh

# Set name of subject here, typically the dir name
# of the package/git repository
subjectname="dolibarr"

# if the subjectname is not the same as the name used
# for the SIR subject package, you can set this to the
# name of the SIR subject package directory
sirsubject="concise_std_pkg"

#
# These can be useful in deriving absolute shell paths within
# the script, or you can use the $experiment_root variable
# and either $subjectname or $sirsubject to form an absolute path
currentdir=`pwd`
parentdir=`dirname ${currentdir} | sed 's,/scripts$,,'`
sourcedir=${parentdir}/source

# The usage function prints a message to the end-user when the
# number of arguments is incorrect.  You can add additional code
# that checks the command-line values for sanity as well and print
# the usage if those checks fail.
function usage {
    echo "Invalid command line for $0"
    echo "usage: $0 version-number additional-option"
    exit 1
}

# General installation script for a SIR subject.  Modify
# to your needs to create an installer for your subject that
# an end-user can use.  An end-user of this script should have
# the correct version installed in an operational/ready-to-test
# state and put into the desired installation location when
# this script finishes.  The installation location can be
# the source directory of the SIR subject package, or another
# location on the end-user's system, which can be one of the
# values you require them to set within the config.sh file.
#
# Common command-line usage of an install.sh script is simply:
# install.sh K
# where K is the version number they user wants to install.
# You can have additional command line arguments expected by your
# script, e.g. a MySQL database name, if you want.  This is all
# dependent on your subject and platform configuration needs.
#

# All scripts typically require the $experiment_root value
# to be set in the shell, see SIR
# users manual for information about the experiment_root shell variable:
# http://sir.unl.edu/content/java-overall.php
#
# this block of code checks if $experiment_root is set:
if [ -z ${experiment_root} ]
then
    echo experiment_root variable unset in shell, set and retry
    exit
fi
#
# This checks that the correct number of command-line arguments are present
# In this case, it expects exactly 2 arguments and will print a usage function
# statement
if [ $# -gt 2 -o \( $# -eq 1 -a \( "$1" = "-?" -o "$1" = "-help" -o "$1" = "--help" \) \) ]
then
    usage
    exit 0
fi

# If you want the install script to have an interactive interface, you can
# use the section here to prompt the end-user for specific values.  This
# code here prompts for a version number and a database name.  Adapt this to
# your needs.
if [ $# -lt 2 ]
then
    echo -n "Version to install "
    read ver
    echo -n "MySQL Database Name "
    read sqldb
else  # handle the command-line arguments when fully supplied
    ver=$1
    sqldb=$2
fi

#
# To check if the version number is really a number, you can use a block
# like this:
if [[ ! ${ver} = *[[:digit:]]* ]]
then
    usage
fi

#
# The next block checks values from the config.sh file.  You can add or
# remove these to suit your installation needs.
if [ -n "${LOCALWEBDIR}" ]
then
    webdir=${LOCALWEBDIR}
else
    echo "\$LOCALWEBDIR unset/empty in config.sh"
    exit 1
fi
if [ -n "${HOST}" ]
then
    svrname=${HOST}
else
    echo "\$HOST unset/empty in config.sh"
    exit 1
fi
if [ -n "${DBUSER}" ]
then
    sqlid=${DBUSER}
else
    echo "\$DBUSER unset/empty in config.sh"
    exit 1
fi
if [ -n "${DBUSERPW}" ]
then
    sqlpw=${DBUSERPW}
else
    echo "\$DBUSERPW unset/empty in config.sh"
    exit 1
fi

if [ -n "${PREFIXDBTABLES}" -a "${PREFIXDBTABLES}" = "1" ]
then
    if [ -n "${DBPREFIX}" ]
    then
        dbprefix=${DBPREFIX}
    else # form a version specific prefix if non specified
        dbprefix="yourcontacts${ver}_"
    fi
fi

# To install a Git project, you will select the URL from the
# giturl file of the versions directory for the specified version number
# Since the giturl file can contain multiple Git URLs, you can
# change the link_line value to select a different GIT url from the giturl file
link_line=1

giturl=`head -${link_line} ${experiment_root}/${subjectname}/versions/v${ver}/giturl | tail -1`
gitcommit=`cat ${experiment_root}/${subjectname}/versions/v${ver}/gitcommit`
# download object from git repo into source directory
dwnldGitObject ${giturl} ${gitcommit}
if [ $? -gt 0 ]
then
    echo "ERROR: install.sh dwldGitObject failed for version ${ver}"
    exit 2
fi

# Custom installation steps can be performed below. The operation shown
# will copy the configured Git project version into the location specified
# by LOCALWEBDIR in the config.sh file as ${subjectname}_${ver} where ${ver}
# is the version specified when the install script is executed

cp -r ${experiment_root}/${sirsubject}/source/${subjectname} ${LOCALWEBDIR}/${subjectname}_v${ver}
