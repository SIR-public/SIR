<?php
/* weak encryption algo used by dolibarr */
if ($argc > 0) {
    $crypt = getCryptedPassword($argv[1]);
    print $crypt;
}

function getCryptedPassword($plaintext)
{
    $encrypted = md5($plaintext);
    return $encrypted;
}

?>
