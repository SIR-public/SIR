<?php
// This is how to get the time back from PHP.  You can run this
// in a shell escape within your code to get the current time
// of the system into a shell variable.  This code script comes
// from the phpagenda subject of the SIR.
    echo time();
?>
